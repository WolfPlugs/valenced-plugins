(function(e,t){Object.defineProperty(e,Symbol.toStringTag,{value:`Module`});function n(){var[e]=valenced.modules.finders.lookupModule(valenced.modules.finders.filters.withProps(`getGuilds`)),[t]=valenced.modules.finders.lookupModule(valenced.modules.finders.filters.withProps(`getGuildEmoji`)),n=e?.getGuilds(),r=[],i=/* @__PURE__ */ new Set;if(n&&typeof n==`object`&&t)for(var a of Object.keys(n)){var o=t.getGuildEmoji(a);if(Array.isArray(o)){for(var s of o)if(typeof s==`object`&&s&&typeof s.id==`string`&&typeof s.name==`string`&&/^\d+$/.test(s.id)&&!i.has(s.id)&&(i.add(s.id),r.push({id:s.id,name:s.name}),r.length>=2e3))break;if(r.length>=2e3)break}}return r}async function r(){var e=n(),t=valenced.modules.native.callNativeMethod;await t(`wolfie.media-utils.emojis`,[e])}var i=`<!doctype html><meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"><style>html,body{margin:0;height:100%;background:#111214;display:flex;align-items:center;justify-content:center;overflow:hidden}canvas{max-width:100%;max-height:100%;object-fit:contain;touch-action:none}</style><body><script>(function runtime() {
  const canvas = document.createElement("canvas");
  document.body.append(canvas);
  const ctx = canvas.getContext("2d"), media = document.createElement("video");
  media.playsInline = !0;
  media.preload = "auto";
  media.style.display = "none";
  document.body.append(media);
  let image, url = "", kind = "image", width = 1, height = 1, rotation = 0, start = 0, end = 0, muted = !1, drawing = !1, cropping = !1, cropRatio = 0, cropStart, cropBox, color = "#ffffff", size = 24, exporting = !1, recorder, captureFrame, audio, source, audioOutput;
  const layers = [];
  let selected, stroke, last;
  const send = (value) => window.ReactNativeWebView.postMessage(JSON.stringify(value)), fail = (error) => send({
    type: "error",
    message: error instanceof Error ? error.message : String(error)
  });
  function draw(showSelection = !0) {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "#000000";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.save();
    ctx.translate(canvas.width / 2, canvas.height / 2);
    ctx.rotate(rotation * Math.PI / 2);
    const source = kind === "image" ? image : media;
    if (source && (kind === "image" || media.readyState >= 2))
      ctx.drawImage(source, -width / 2, -height / 2, width, height);
    ctx.restore();
    for (const layer of layers)
      if (layer.kind === "ink") {
        ctx.strokeStyle = layer.color;
        ctx.lineWidth = layer.size;
        ctx.lineCap = "round";
        ctx.lineJoin = "round";
        ctx.beginPath();
        layer.points.forEach((p, i) => i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y));
        ctx.stroke();
      } else if (layer.kind === "text") {
        ctx.font = \`bold \${layer.size}px sans-serif\`;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.lineWidth = Math.max(2, layer.size / 14);
        ctx.strokeStyle = "#000000";
        ctx.fillStyle = layer.color;
        ctx.strokeText(layer.text, layer.x, layer.y);
        ctx.fillText(layer.text, layer.x, layer.y);
      } else
        ctx.drawImage(layer.image, layer.x - layer.size / 2, layer.y - layer.size / 2, layer.size, layer.size);
    if (showSelection && cropBox) {
      ctx.strokeStyle = "#ffffff";
      ctx.lineWidth = Math.max(2, canvas.width / 400);
      ctx.setLineDash([10, 5]);
      ctx.strokeRect(cropBox.x, cropBox.y, cropBox.width, cropBox.height);
      ctx.setLineDash([]);
    }
  }
  function resize() {
    canvas.width = rotation % 2 ? height : width;
    canvas.height = rotation % 2 ? width : height;
    draw();
  }
  function ready() {
    const scale = Math.min(1, (kind === "video" ? 1920 : 4096) / Math.max(width, height));
    width = Math.max(2, Math.floor(width * scale / 2) * 2);
    height = Math.max(2, Math.floor(height * scale / 2) * 2);
    resize();
    send({
      type: "ready",
      width,
      height,
      duration: end,
      videoSupported: typeof MediaRecorder < "u" && typeof canvas.captureStream === "function"
    });
  }
  media.onloadedmetadata = () => {
    width = media.videoWidth;
    height = media.videoHeight;
    end = media.duration;
    ready();
  };
  media.onseeked = () => draw();
  media.onloadeddata = () => draw();
  media.onerror = () => fail(Error("This video format cannot be opened by Android WebView."));
  function point(event) {
    const rect = canvas.getBoundingClientRect();
    return {
      x: (event.clientX - rect.left) * canvas.width / rect.width,
      y: (event.clientY - rect.top) * canvas.height / rect.height
    };
  }
  canvas.onpointerdown = (event) => {
    if (exporting)
      return;
    canvas.setPointerCapture(event.pointerId);
    last = point(event);
    if (cropping) {
      cropStart = last;
      return;
    }
    if (drawing) {
      stroke = {
        kind: "ink",
        points: [last],
        color,
        size: size * canvas.width / 400
      };
      layers.push(stroke);
    } else {
      selected = void 0;
      for (let i = layers.length - 1;i >= 0; i--) {
        const layer = layers[i];
        if (layer.kind === "ink")
          continue;
        const halfWidth = layer.kind === "emoji" ? layer.size / 2 : Math.max(layer.size, layer.text.length * layer.size * 0.35);
        if (Math.abs(layer.x - last.x) < halfWidth && Math.abs(layer.y - last.y) < layer.size) {
          selected = layer;
          break;
        }
      }
    }
  };
  canvas.onpointermove = (event) => {
    if (!last || exporting)
      return;
    const next = point(event);
    if (cropping && cropStart) {
      const x = Math.max(0, Math.min(canvas.width - 1, Math.min(cropStart.x, next.x))), y = Math.max(0, Math.min(canvas.height - 1, Math.min(cropStart.y, next.y)));
      let width = Math.max(1, Math.min(canvas.width - x, Math.abs(next.x - cropStart.x))), height = Math.max(1, Math.min(canvas.height - y, Math.abs(next.y - cropStart.y)));
      if (cropRatio > 0) {
        width = Math.min(width, (canvas.height - y) * cropRatio);
        height = width / cropRatio;
      }
      cropBox = { x, y, width, height };
    } else if (stroke)
      stroke.points.push(next);
    else if (selected) {
      selected.x += next.x - last.x;
      selected.y += next.y - last.y;
    }
    last = next;
    draw();
  };
  canvas.onpointerup = canvas.onpointercancel = () => {
    last = void 0;
    cropStart = void 0;
    stroke = void 0;
  };
  async function encode() {
    if (exporting)
      return;
    if (kind === "image") {
      draw(!1);
      const output = document.createElement("canvas"), bounds = cropBox ?? {
        x: 0,
        y: 0,
        width: canvas.width,
        height: canvas.height
      };
      output.width = Math.max(1, Math.round(bounds.width));
      output.height = Math.max(1, Math.round(bounds.height));
      output.getContext("2d").drawImage(canvas, bounds.x, bounds.y, bounds.width, bounds.height, 0, 0, output.width, output.height);
      send({
        type: "result",
        mime: "image/png",
        width: output.width,
        height: output.height,
        data: output.toDataURL("image/png").split(",")[1]
      });
      draw();
      return;
    }
    if (!(Number.isFinite(end) && end > start && start >= 0 && end <= media.duration))
      throw Error("Choose a valid start and end time.");
    const mime = [
      "video/mp4;codecs=avc1.42E01E,mp4a.40.2",
      "video/webm;codecs=vp8,opus",
      "video/webm"
    ].find((value) => MediaRecorder.isTypeSupported(value));
    if (!mime)
      throw Error("Video export is unavailable in this Android WebView.");
    exporting = !0;
    media.pause();
    media.currentTime = start;
    if (media.seeking)
      await new Promise((resolve) => media.addEventListener("seeked", () => resolve(), { once: !0 }));
    const bounds = cropBox ?? {
      x: 0,
      y: 0,
      width: canvas.width,
      height: canvas.height
    }, output = document.createElement("canvas");
    output.width = Math.max(2, Math.floor(bounds.width / 2) * 2);
    output.height = Math.max(2, Math.floor(bounds.height / 2) * 2);
    const outputContext = output.getContext("2d"), copyFrame = () => outputContext.drawImage(canvas, bounds.x, bounds.y, bounds.width, bounds.height, 0, 0, output.width, output.height);
    captureFrame = copyFrame;
    draw(!1);
    copyFrame();
    const stream = output.captureStream(30);
    if (!muted) {
      audio ??= new AudioContext;
      source ??= audio.createMediaElementSource(media);
      audioOutput = audio.createMediaStreamDestination();
      source.disconnect();
      source.connect(audioOutput);
      await audio.resume();
      for (const track of audioOutput.stream.getAudioTracks())
        stream.addTrack(track);
    }
    const chunks = [];
    let bytes = 0;
    recorder = new MediaRecorder(stream, {
      mimeType: mime,
      videoBitsPerSecond: 8000000
    });
    recorder.ondataavailable = (event) => {
      bytes += event.data.size;
      if (bytes > 67108864) {
        window.mediaCommand({ type: "cancel" });
        fail(Error("The edited video exceeds the 64 MB export limit. Trim a shorter clip."));
      } else
        chunks.push(event.data);
    };
    recorder.onerror = () => {
      window.mediaCommand({ type: "cancel" });
      fail(Error("Android WebView could not encode this video."));
    };
    recorder.onstop = () => {
      captureFrame = void 0;
      stream.getTracks().forEach((track) => track.stop());
      if (!exporting)
        return;
      exporting = !1;
      media.pause();
      if (audio && source) {
        source.disconnect();
        source.connect(audio.destination);
      }
      const reader = new FileReader;
      reader.onload = () => {
        if (typeof reader.result === "string")
          send({
            type: "result",
            mime: mime.startsWith("video/mp4") ? "video/mp4" : "video/webm",
            width: output.width,
            height: output.height,
            duration: end - start,
            data: reader.result.slice(reader.result.indexOf(";base64,") + 8)
          });
      };
      reader.onerror = () => fail(Error("Could not read the exported video."));
      reader.readAsDataURL(new Blob(chunks, { type: mime }));
    };
    draw();
    recorder.start(1000);
    await media.play();
  }
  function frame() {
    if (kind === "video" && !media.paused) {
      draw(!exporting);
      captureFrame?.();
      if (exporting) {
        send({
          type: "progress",
          value: Math.min(1, (media.currentTime - start) / (end - start))
        });
        if (media.currentTime >= end || media.ended) {
          media.pause();
          if (recorder?.state === "recording")
            recorder.stop();
        }
      } else if (media.currentTime >= end)
        media.pause();
    }
    requestAnimationFrame(frame);
  }
  media.ontimeupdate = () => send({ type: "playhead", time: media.currentTime, playing: !media.paused });
  media.onplay = media.onpause = () => send({ type: "playhead", time: media.currentTime, playing: !media.paused });
  media.onended = () => {
    if (recorder?.state === "recording")
      recorder.stop();
  };
  window.mediaCommand = (command) => {
    try {
      if (command.type === "cancel") {
        exporting = !1;
        if (recorder?.state === "recording")
          recorder.stop();
        media.pause();
        audio?.close();
        audio = void 0;
        source = void 0;
        audioOutput = void 0;
        return;
      }
      if (exporting)
        return;
      switch (command.type) {
        case "seek":
          media.pause();
          media.currentTime = Math.max(start, Math.min(end, command.time));
          break;
        case "thumbnails": {
          const video = document.createElement("video");
          video.muted = !0;
          video.preload = "auto";
          const thumbnail = document.createElement("canvas");
          thumbnail.width = 96;
          thumbnail.height = 72;
          const context = thumbnail.getContext("2d"), frames = [];
          video.onloadeddata = () => {
            video.currentTime = Math.min(0.01, video.duration / 2);
          };
          video.onseeked = () => {
            context.drawImage(video, 0, 0, 96, 72);
            frames.push(thumbnail.toDataURL("image/jpeg", 0.65));
            if (frames.length < 8)
              video.currentTime = Math.min(video.duration - 0.01, frames.length / 8 * video.duration);
            else {
              send({ type: "thumbnails", frames });
              video.removeAttribute("src");
              video.load();
            }
          };
          video.onerror = () => {
            video.removeAttribute("src");
            video.load();
          };
          video.src = url;
          break;
        }
        case "load": {
          cropBox = void 0;
          cropping = !1;
          layers.length = 0;
          selected = void 0;
          rotation = 0;
          start = 0;
          end = 0;
          if (url)
            URL.revokeObjectURL(url);
          const binary = atob(command.data), bytes = Uint8Array.from(binary, (c) => c.charCodeAt(0));
          url = URL.createObjectURL(new Blob([bytes], { type: command.mime }));
          kind = command.kind;
          if (kind === "video") {
            media.src = url;
            media.load();
          } else {
            image = new Image;
            image.onload = () => {
              width = image.naturalWidth;
              height = image.naturalHeight;
              ready();
            };
            image.onerror = () => fail(Error("Could not open this image."));
            image.src = url;
          }
          break;
        }
        case "crop":
          cropping = !0;
          cropRatio = command.ratio ?? 0;
          drawing = !1;
          if (command.ratio && command.ratio > 0) {
            const width = Math.min(canvas.width, canvas.height * command.ratio), height = width / command.ratio;
            cropBox = {
              x: (canvas.width - width) / 2,
              y: (canvas.height - height) / 2,
              width,
              height
            };
          }
          break;
        case "reset-crop":
          cropBox = void 0;
          cropping = !1;
          break;
        case "tool":
          cropping = !1;
          drawing = command.draw;
          color = command.color;
          size = command.size;
          if (selected) {
            selected.size = size * canvas.width / 400;
            if (selected.kind === "text")
              selected.color = color;
          }
          break;
        case "text":
          cropping = !1;
          selected = {
            kind: "text",
            text: command.text,
            color: command.color,
            size: command.size * canvas.width / 400,
            x: canvas.width / 2,
            y: canvas.height / 2
          };
          layers.push(selected);
          drawing = !1;
          break;
        case "emoji": {
          cropping = !1;
          const emoji = new Image;
          emoji.onload = () => {
            selected = {
              kind: "emoji",
              image: emoji,
              size: canvas.width / 5,
              x: canvas.width / 2,
              y: canvas.height / 2
            };
            layers.push(selected);
            draw();
          };
          emoji.onerror = () => fail(Error("Could not load this emoji."));
          emoji.src = command.data;
          drawing = !1;
          break;
        }
        case "rotate":
          cropBox = void 0;
          rotation = (rotation + 1) % 4;
          resize();
          break;
        case "undo":
          layers.pop();
          selected = void 0;
          break;
        case "trim":
          start = command.start;
          end = command.end;
          muted = command.muted;
          media.muted = muted;
          media.currentTime = start;
          break;
        case "preview":
          if (kind === "video")
            if (media.paused) {
              media.currentTime = start;
              media.play().catch(fail);
            } else
              media.pause();
          break;
        case "export":
          encode().catch((error) => {
            window.mediaCommand({ type: "cancel" });
            fail(error);
          });
          break;
      }
      draw();
    } catch (error) {
      fail(error);
    }
  };
  frame();
  send({ type: "boot" });
})()<\/script>`;async function a(e){var t=e;if(/^content:\/\//i.test(e)){var n=valenced.modules.native.callNativeMethod,r=await n(`wolfie.media-utils.readMedia`,[e]);if(typeof r!=`string`||!r)throw Error(`Android returned no attachment data.`);return r}if(/^file:\/\//i.test(t)){var i=t.replace(/^file:\/\/(?:localhost)?/i,``);return valenced.discord.native.FileModule.readFile(decodeURIComponent(i),`base64`)}if(t.startsWith(`/`))return valenced.discord.native.FileModule.readFile(t,`base64`);if(/^https?:\/\//i.test(t))return valenced.discord.native.FileModule.readAsset(t,`base64`);throw Error(`Unsupported attachment URI. Choose a local image or video file.`)}function o(e,t,n){var r=Math.min(e,Math.max(.5,e/5));return{from:Math.max(0,Math.min(e-r,t-r*(n===`start`?.25:.75))),span:r}}function s(e,t,n,r){return e+t/Math.max(1,n)*r}function c({duration:e,start:n,end:r,position:i,frames:a,onTrim:c,onSeek:l}){var[u,d]=valenced.react.React.useState(1),f=valenced.react.React.useRef({duration:e,start:n,end:r,width:u,onTrim:c});f.current={duration:e,start:n,end:r,width:u,onTrim:c};var p=valenced.react.React.useRef(0),m=valenced.react.React.useRef(0),h=valenced.react.React.useRef(0),g=valenced.react.React.useRef(void 0),[_,v]=valenced.react.React.useState(null),y=valenced.react.React.useRef(_);function b(){clearTimeout(g.current),g.current=void 0,y.current=null,v(null)}valenced.react.React.useEffect(function(){return function(){return clearTimeout(g.current)}},[]);function x(e){return valenced.react.ReactNative.PanResponder.create({onStartShouldSetPanResponder:function(){return!0},onMoveShouldSetPanResponder:function(){return!0},onPanResponderGrant:function(){p.current=f.current[e],m.current=0,h.current=0,clearTimeout(g.current),g.current=setTimeout(function(){var t=f.current,n=o(t.duration,t[e],e);p.current=t[e],h.current=m.current,y.current=n,v(n)},400)},onPanResponderMove:function(t,n){var r=f.current;m.current=n.dx;var i=s(p.current,n.dx-h.current,r.width,y.current?.span??r.duration),a=Math.min(.1,r.duration);e===`start`?r.onTrim(Math.max(0,Math.min(i,r.end-a)),r.end):r.onTrim(r.start,Math.min(r.duration,Math.max(i,r.start+a)))},onPanResponderRelease:b,onPanResponderTerminate:b,onPanResponderTerminationRequest:function(){return!0}}).panHandlers}var[S]=valenced.react.React.useState(function(){return x(`start`)}),[C]=valenced.react.React.useState(function(){return x(`end`)}),w=function(t){return Math.max(0,Math.min(1,(t-(_?.from??0))/(_?.span||e||1)))};return/*#__PURE__*/ (0,t.jsxs)(valenced.react.ReactNative.View,{style:{gap:8,paddingHorizontal:12},children:[/*#__PURE__*/ (0,t.jsxs)(valenced.react.ReactNative.View,{style:{height:56,marginHorizontal:12},onLayout:function(e){return d(e.nativeEvent.layout.width)},children:[/*#__PURE__*/ (0,t.jsx)(valenced.react.ReactNative.View,{style:{flexDirection:`row`,height:56,overflow:`hidden`,borderRadius:8,backgroundColor:`#303136`},onStartShouldSetResponder:function(){return!0},onResponderRelease:function(t){return l(Math.max(0,Math.min(e,(_?.from??0)+t.nativeEvent.locationX/u*(_?.span??e))))},children:/*#__PURE__*/ (0,t.jsx)(valenced.react.ReactNative.View,{pointerEvents:`none`,style:{flexDirection:`row`,position:`absolute`,height:56,width:u*e/(_?.span||e||1),left:-(_?.from??0)/(_?.span||e||1)*u},children:a.map(function(e,n){return/*#__PURE__*/ (0,t.jsx)(valenced.react.ReactNative.Image,{source:{uri:e},style:{flex:1,height:56},resizeMode:`cover`},n)})})}),/*#__PURE__*/ (0,t.jsx)(valenced.react.ReactNative.View,{pointerEvents:`none`,style:{position:`absolute`,left:0,top:0,bottom:0,width:w(n)*u,backgroundColor:`#00000099`}}),/*#__PURE__*/ (0,t.jsx)(valenced.react.ReactNative.View,{pointerEvents:`none`,style:{position:`absolute`,right:0,top:0,bottom:0,width:(1-w(r))*u,backgroundColor:`#00000099`}}),/*#__PURE__*/ (0,t.jsx)(valenced.react.ReactNative.View,{pointerEvents:`none`,style:{position:`absolute`,top:0,bottom:0,left:w(n)*u,width:(w(r)-w(n))*u,borderTopWidth:2,borderBottomWidth:2,borderColor:`#ffffff`}}),/*#__PURE__*/ (0,t.jsx)(valenced.react.ReactNative.View,{pointerEvents:`none`,style:{position:`absolute`,top:-4,bottom:-4,width:2,backgroundColor:`#ffffff`,left:w(i)*u}}),[{edge:`start`,time:n,handlers:S},{edge:`end`,time:r,handlers:C}].map(function({edge:i,time:a,handlers:o}){return/*#__PURE__*/ (0,t.jsx)(valenced.react.ReactNative.View,{...o,accessible:!0,accessibilityRole:`adjustable`,accessibilityLabel:`${i} of clip`,accessibilityValue:{min:0,max:e,now:a},accessibilityActions:[{name:`increment`},{name:`decrement`}],onAccessibilityAction:function(t){var a=(i===`start`?n:r)+(t.nativeEvent.actionName===`increment`?.1:-.1);i===`start`?c(Math.max(0,Math.min(a,r-Math.min(.1,e))),r):c(n,Math.min(e,Math.max(a,n+Math.min(.1,e))))},style:{position:`absolute`,left:w(a)*u-12,top:-4,width:24,height:64,borderRadius:6,backgroundColor:`#ffffff`,alignItems:`center`,justifyContent:`center`},children:/*#__PURE__*/ (0,t.jsx)(valenced.react.ReactNative.View,{style:{width:3,height:20,backgroundColor:`#111214`,borderRadius:2}})},i)})]}),/*#__PURE__*/ (0,t.jsxs)(valenced.react.ReactNative.View,{style:{flexDirection:`row`,justifyContent:`space-between`},children:[/*#__PURE__*/ (0,t.jsxs)(valenced.discord.design.Design.Text,{style:{color:`#b5bac1`},children:[n.toFixed(_?2:1),`s`]}),_&&/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.Text,{style:{color:`#ffffff`},children:`Precision trim`}),/*#__PURE__*/ (0,t.jsxs)(valenced.discord.design.Design.Text,{style:{color:`#b5bac1`},children:[r.toFixed(_?2:1),`s`]})]})]})}function l(e,t){for(var n=1;n<=4&&!(e[t]&1<<8-n);)n++;if(n>4)throw Error(`Invalid WebM element.`);for(var r=0,i=0;i<n;i++)r=r*256+e[t+i];for(var a=t+n,o=1;o<=8&&!(e[a]&1<<8-o);)o++;if(o>8||a+o>e.length)throw Error(`Invalid WebM size.`);for(var s=e[a]&(1<<8-o)-1,c=s===(1<<8-o)-1,l=1;l<o;l++)s=s*256+e[a+l],c&&(c=e[a+l]===255);var u=a+o;if(!c&&(!Number.isSafeInteger(s)||u+s>e.length))throw Error(`Truncated WebM.`);return{id:r,start:t,data:u,end:c?e.length:u+s,sizeBytes:o,size:c?1/0:s}}function u(e,t,n){var r=t.data-t.sizeBytes;if(n>=2**(7*t.sizeBytes)-1)throw Error(`WebM metadata is too large.`);for(var i=t.sizeBytes-1;i>=0;i--)e[r+i]=n%256,n=Math.floor(n/256);e[r]|=1<<8-t.sizeBytes}function d(e,t){if(!Number.isFinite(t)||t<=0)throw Error(`Invalid video duration.`);for(var n,r=0;r<e.length;){var i=l(e,r);if(i.id===408125543){n=i;break}r=i.end}if(!n)throw Error(`WebM segment is missing.`);for(var a,o=n.data;o<n.end;){var s=l(e,o);if(s.id===290298740)return e;if(s.id===357149030){a=s;break}o=s.end}if(!a||!Number.isFinite(a.size))throw Error(`WebM metadata is missing.`);for(var c=1e6,d=a.data;d<a.end;){var f=l(e,d);if(f.id===17545)return e;if(f.id===2807729){c=0;for(var p=f.data;p<f.end;p++)c=c*256+e[p]}d=f.end}var m=/* @__PURE__ */ new Uint8Array(11);m.set([68,137,136]),new DataView(m.buffer).setFloat64(3,t*1e9/c);var h=new Uint8Array(e.length+m.length);return h.set(e.subarray(0,a.end)),h.set(m,a.end),h.set(e.subarray(a.end),a.end+m.length),u(h,a,a.size+m.length),Number.isFinite(n.size)&&u(h,n,n.size+m.length),h}var f=`wolfie.media-utils.overlay`,p,m=[`#ffffff`,`#000000`,`#ed4245`,`#fee75c`,`#57f287`,`#5865f2`,`#eb459e`];function h({item:e,kind:n,WebView:r,onEdit:o,reportError:s,isCurrent:l}){var u=valenced.react.React.useRef(null),f=valenced.react.React.useRef(!0),h=valenced.react.React.useRef(!1),[g,v]=valenced.react.React.useState(!0),[y,b]=valenced.react.React.useState(!1),[x,S]=valenced.react.React.useState(!1),[C,w]=valenced.react.React.useState(``),[T,E]=valenced.react.React.useState(0),[D,O]=valenced.react.React.useState([]),[k,A]=valenced.react.React.useState(0),[j,ee]=valenced.react.React.useState(!1),[M,N]=valenced.react.React.useState(0),[P,te]=valenced.react.React.useState(0),[F,I]=valenced.react.React.useState(0),[L,R]=valenced.react.React.useState(!1),[z,B]=valenced.react.React.useState(`Trim`),V=z===`Paint`,[H,ne]=valenced.react.React.useState(`#ffffff`),[U,W]=valenced.react.React.useState(24),[G,K]=valenced.react.React.useState(``),[q,re]=valenced.react.React.useState(``),[J]=valenced.react.React.useState(function(){return[]}),ie=valenced.react.React.useRef({html:i}).current;function Y(e){u.current?.injectJavaScript(`window.mediaCommand(${JSON.stringify(e)});true;`)}function X(e){f.current&&(h.current=!1,S(!1),w(e instanceof Error?e.message:String(e)),s(e))}valenced.react.React.useEffect(function(){var e=function(){f.current=!1,Y({type:`cancel`}),v(!1)};return p=e,function(){f.current=!1,Y({type:`cancel`}),p===e&&(p=void 0)}},[]),valenced.react.React.useEffect(function(){y&&z!==`Crop`&&Y({type:`tool`,draw:V,color:H,size:U})},[V,H,U,y,z]),valenced.react.React.useEffect(function(){y&&n===`video`&&Y({type:`trim`,start:P,end:F,muted:L})},[P,F,L,y]);async function ae(e){if(typeof e==`object`&&e){if(B(`Text`),`id`in e&&typeof e.id==`string`&&/^\d+$/.test(e.id))try{var t=await valenced.discord.native.FileModule.readAsset(`https://cdn.discordapp.com/emojis/${e.id}.png?size=256`,`base64`);f.current&&Y({type:`emoji`,data:`data:image/png;base64,${t}`})}catch(e){X(e)}else`surrogates`in e&&typeof e.surrogates==`string`&&Y({type:`text`,text:e.surrogates,color:H,size:64})}}async function Z(t){if(f.current&&l())try{var r=JSON.parse(t);if(typeof r!=`object`||!r||!(`type`in r))return;if(r.type===`boot`){var i=await a(e.uri);if(!f.current||!l())return;if(i.length>268435456/3)throw Error(`This editor currently supports source files up to 64 MB.`);Y({type:`load`,data:i,kind:n,mime:e.mimeType??(n===`video`?`video/mp4`:`image/png`)})}else if(r.type===`thumbnails`&&`frames`in r&&Array.isArray(r.frames))O(r.frames.filter(function(e){return typeof e==`string`&&e.startsWith(`data:image/jpeg;base64,`)}).slice(0,8));else if(r.type===`playhead`&&`time`in r&&typeof r.time==`number`)A(r.time),ee(`playing`in r&&r.playing===!0);else if(r.type===`ready`){if(n===`video`&&(!(`videoSupported`in r)||!r.videoSupported))throw Error(`Update Android System WebView to enable video export.`);`duration`in r&&typeof r.duration==`number`&&Number.isFinite(r.duration)&&(N(r.duration),I(r.duration)),b(!0),Y({type:`thumbnails`})}else if(r.type===`progress`&&`value`in r&&typeof r.value==`number`)E(r.value);else if(r.type===`error`&&`message`in r)throw Error(String(r.message));else if(r.type===`result`&&h.current){if(!(`data`in r)||typeof r.data!=`string`||r.data.length>9e7||!/^[A-Za-z0-9+/]*={0,2}$/.test(r.data)||!(`mime`in r)||![`image/png`,`video/mp4`,`video/webm`].includes(String(r.mime))||!(`width`in r)||typeof r.width!=`number`||!(`height`in r)||typeof r.height!=`number`)throw Error(`Invalid media export.`);var s=String(r.mime);if(n===`image`!=(s===`image/png`))throw Error(`Unexpected export format.`);var c=s===`image/png`?`png`:s===`video/mp4`?`mp4`:`webm`,u=`media-utils-${Date.now()}.${c}`,p=`media-utils/${u}`,m=r.data;if(s===`video/webm`){if(!(`duration`in r)||typeof r.duration!=`number`)throw Error(`Missing video duration.`);for(var g=d(Uint8Array.from(atob(m),function(e){return e.charCodeAt(0)}),r.duration),v=[],y=0;y<g.length;y+=8190)v.push(btoa(String.fromCharCode(...g.subarray(y,y+8190))));m=v.join(``)}var x=await valenced.discord.native.FileModule.writeFile(`cache`,p,m,`base64`);if(!f.current||!l()){await valenced.discord.native.FileModule.removeFile(`cache`,p);return}var S=x.startsWith(`file://`)?x:`file://${x}`;try{o({id:u,uri:S,originalUri:S,filename:u,mimeType:s,width:r.width,height:r.height,platform:0,origin:1})}catch(e){throw await valenced.discord.native.FileModule.removeFile(`cache`,p),e}h.current=!1,_()}}catch(e){X(e)}}function Q(){f.current=!1,v(!1),_()}function oe(e){x||e!==`Trim`&&e!==`Crop`||(B(e),Y(e===`Crop`?{type:`crop`}:{type:`tool`,draw:e===`Paint`,color:H,size:U}))}function $(){y&&!h.current&&(h.current=!0,S(!0),w(``),Y({type:`export`}))}return/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.ActionSheet,{children:/*#__PURE__*/ (0,t.jsx)(valenced.react.ReactNative.View,{style:{height:1},children:/*#__PURE__*/ (0,t.jsx)(valenced.react.ReactNative.Modal,{visible:g,animationType:`slide`,onRequestClose:Q,children:/*#__PURE__*/ (0,t.jsx)(valenced.externals.ReactNativeSafeAreaContext.ReactNativeSafeAreaContext.SafeAreaProvider,{children:/*#__PURE__*/ (0,t.jsx)(valenced.externals.ReactNativeSafeAreaContext.ReactNativeSafeAreaContext.SafeAreaView,{edges:[`top`,`bottom`,`left`,`right`],style:{flex:1,backgroundColor:`#111214`},children:/*#__PURE__*/ (0,t.jsxs)(valenced.react.ReactNative.KeyboardAvoidingView,{behavior:`height`,style:{flex:1,backgroundColor:`#111214`},children:[/*#__PURE__*/ (0,t.jsxs)(valenced.react.ReactNative.View,{style:{flexDirection:`row`,alignItems:`center`,justifyContent:`space-between`,padding:12},children:[/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.Button,{text:`Cancel`,variant:`tertiary`,size:`sm`,onPress:Q}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.Text,{style:{color:`#ffffff`,fontSize:18,fontWeight:`600`},children:`Edit video`}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.Button,{text:x?`${Math.round(T*100)}%`:`Save`,size:`sm`,disabled:!y||x,onPress:$})]}),/*#__PURE__*/ (0,t.jsx)(valenced.react.ReactNative.View,{style:{flex:1,minHeight:0,overflow:`hidden`},children:/*#__PURE__*/ (0,t.jsx)(r,{ref:u,source:ie,style:{flex:1,backgroundColor:`#111214`},containerStyle:{flex:1},javaScriptEnabled:!0,mediaPlaybackRequiresUserAction:!1,allowsInlineMediaPlayback:!0,originWhitelist:[`about:blank`],onMessage:function(e){Z(e.nativeEvent.data)},onError:function(){return X(/* @__PURE__ */ Error(`The media canvas failed to load.`))},onContentProcessDidTerminate:function(){return X(/* @__PURE__ */ Error(`Android closed the editor. Reopen it to continue.`))}})}),/*#__PURE__*/ (0,t.jsxs)(valenced.react.ReactNative.View,{style:{flexShrink:0,backgroundColor:`#111214`,padding:12,gap:12},children:[C?/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.Text,{style:{color:`#ff858b`},children:C}):null,!y&&!C?/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.Text,{style:{color:`#ffffff`},children:`Loading video…`}):null,x?/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.Text,{style:{color:`#ffffff`},children:`Saving video… Keep this screen open.`}):y&&/*#__PURE__*/ (0,t.jsxs)(t.Fragment,{children:[/*#__PURE__*/ (0,t.jsxs)(valenced.react.ReactNative.View,{style:{flexDirection:`row`,justifyContent:`space-between`,alignItems:`center`},children:[/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.Button,{text:j?`Pause`:`Play`,variant:`secondary`,size:`sm`,onPress:function(){return Y({type:`preview`})}}),/*#__PURE__*/ (0,t.jsxs)(valenced.discord.design.Design.Text,{style:{color:`#ffffff`},children:[k.toFixed(1),` / `,F.toFixed(1),`s`]}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.Button,{text:`Undo`,variant:`tertiary`,size:`sm`,onPress:function(){return Y({type:`undo`})}})]}),/*#__PURE__*/ (0,t.jsx)(c,{duration:M,start:P,end:F,position:k,frames:D,onTrim:function(e,t){te(e),I(t)},onSeek:function(e){return Y({type:`seek`,time:e})}}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.Button,{text:L?`Sound off`:`Sound on`,variant:`tertiary`,size:`sm`,onPress:function(){return R(!L)}}),z!==`Trim`&&/*#__PURE__*/ (0,t.jsx)(valenced.react.ReactNative.View,{style:{height:146},children:/*#__PURE__*/ (0,t.jsxs)(valenced.react.ReactNative.ScrollView,{keyboardShouldPersistTaps:`handled`,contentContainerStyle:{gap:10},children:[z===`Crop`&&/*#__PURE__*/ (0,t.jsxs)(t.Fragment,{children:[/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.Text,{style:{color:`#ffffff`},children:`Drag across the preview to crop.`}),/*#__PURE__*/ (0,t.jsx)(valenced.react.ReactNative.View,{style:{flexDirection:`row`,gap:8,flexWrap:`wrap`},children:[{label:`Free`,ratio:0},{label:`1:1`,ratio:1},{label:`4:5`,ratio:4/5},{label:`9:16`,ratio:9/16},{label:`16:9`,ratio:16/9}].map(function({label:e,ratio:n}){return/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.Button,{text:e,variant:`secondary`,size:`sm`,onPress:function(){return Y({type:`crop`,ratio:n})}},e)})}),/*#__PURE__*/ (0,t.jsxs)(valenced.react.ReactNative.View,{style:{flexDirection:`row`,gap:8},children:[/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.Button,{text:`Rotate 90°`,variant:`secondary`,size:`sm`,onPress:function(){Y({type:`rotate`}),Y({type:`crop`})}}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.Button,{text:`Reset crop`,variant:`tertiary`,size:`sm`,onPress:function(){Y({type:`reset-crop`}),Y({type:`crop`})}})]})]}),z===`Emoji`&&/*#__PURE__*/ (0,t.jsxs)(t.Fragment,{children:[/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TextInput,{value:q,onChange:re,placeholder:`Search server emojis`}),/*#__PURE__*/ (0,t.jsx)(valenced.react.ReactNative.View,{style:{flexDirection:`row`,flexWrap:`wrap`,gap:8},children:J.filter(function(e){return e.name.toLowerCase().includes(q.toLowerCase())}).slice(0,60).map(function(e){return/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.Button,{text:e.name,variant:`secondary`,size:`sm`,renderIcon:function(){return/*#__PURE__*/ (0,t.jsx)(valenced.react.ReactNative.Image,{source:{uri:`https://cdn.discordapp.com/emojis/${e.id}.png?size=64`},style:{width:24,height:24}})},onPress:function(){ae(e)}},e.id)})}),J.length===0&&/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.Text,{style:{color:`#b5bac1`},children:`No server emojis loaded. Use Text to add a keyboard emoji.`})]}),z===`Text`&&/*#__PURE__*/ (0,t.jsxs)(valenced.react.ReactNative.View,{style:{flexDirection:`row`,alignItems:`center`,gap:8},children:[/*#__PURE__*/ (0,t.jsx)(valenced.react.ReactNative.View,{style:{flex:1},children:/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TextInput,{value:G,onChange:K,placeholder:`Add text`})}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.Button,{text:`Add`,size:`sm`,onPress:function(){G.trim()&&(Y({type:`text`,text:G.trim(),color:H,size:U}),K(``))}})]}),(z===`Text`||z===`Paint`)&&/*#__PURE__*/ (0,t.jsxs)(t.Fragment,{children:[/*#__PURE__*/ (0,t.jsx)(valenced.react.ReactNative.ScrollView,{horizontal:!0,showsHorizontalScrollIndicator:!1,contentContainerStyle:{gap:8},children:m.map(function(e){return/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.Button,{accessibilityLabel:`Color ${e}`,text:e===H?`●`:`○`,variant:`secondary`,size:`sm`,textStyle:{color:e},onPress:function(){return ne(e)}},e)})}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.Slider,{minimumValue:4,maximumValue:100,step:1,value:U,onValueChange:W}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.Text,{style:{color:`#b5bac1`},children:z===`Paint`?`Draw on the preview with your finger.`:`Drag text or emoji to move it.`})]})]})}),/*#__PURE__*/ (0,t.jsx)(valenced.react.ReactNative.View,{style:{flexDirection:`row`,justifyContent:`space-between`,gap:4},children:[`Trim`,`Crop`].map(function(e){return/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.Button,{text:e,variant:z===e?`primary`:`secondary`,size:`sm`,style:{flex:1,minWidth:0,paddingHorizontal:0},textStyle:{fontSize:12},onPress:function(){return oe(e)}},e)})})]})]})]})})})})})})}function g(e){valenced.discord.actions.ActionSheetActionCreators.hideActionSheet(`UploadPreviewActionSheet`),valenced.discord.actions.ActionSheetActionCreators.openLazy(Promise.resolve({default:h}),f,e)}function _(){p?.(),valenced.discord.actions.ActionSheetActionCreators.hideActionSheet(f)}function v({message:e}){return/*#__PURE__*/ (0,t.jsxs)(valenced.discord.design.Design.ActionSheet,{header:/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.BottomSheetTitleHeader,{title:`Could not open editor`}),children:[/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRow,{label:`MediaUtils`,subLabel:e}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.ActionSheetRow,{label:`Close`,onPress:_})]})}function y(e){valenced.discord.actions.ActionSheetActionCreators.openLazy(Promise.resolve({default:v}),f,{message:e instanceof Error?e.message:String(e)},`stack`)}function b(){var[e]=valenced.modules.finders.lookupModule(valenced.modules.finders.filters.withProps(`isFileUploadSupported`));if(e)return e;if(typeof valenced.react.ReactNative.codegenNativeCommands==`function`){var t=valenced.react.ReactModuleId,n=valenced.react.ReactNativeModuleId,r=valenced.react.ReactJSXRuntimeModuleId,[,i]=valenced.modules.finders.lookupModule(valenced.modules.finders.filters.withName(`codegenNativeCommands`));if(t!==void 0&&n!==void 0&&r!==void 0&&i!==void 0){var{relative:a}=valenced.modules.finders.filters.withDependencies,[o]=valenced.modules.finders.lookupModule(valenced.modules.finders.filters.withDependencies([t,n,r,i,a(1),null,null,a(3),a(4)]),{returnNamespace:!0}),s=o?.default;return s&&`isFileUploadSupported`in s?s:void 0}}}function x(e,n){var i,a,o=!1;e(function(){o=!0,_()}),e(valenced.modules.finders.getModules(valenced.modules.finders.filters.withProps(`isFileUploadSupported`),function(e){i=e},{max:1})),e(valenced.modules.finders.getModules(valenced.modules.finders.filters.withProps(`openEmojiPickerActionSheet`),function(e){a=e},{max:1})),e(valenced.modules.finders.getModules(valenced.modules.finders.filters.withName(`UploadPreviewActionSheet`),function(s){`default`in s&&typeof s.default==`function`&&e(valenced.patcher.instead(s,`default`,function(e,s){var c=Reflect.apply(s,this,e),l=e[0];if(typeof l!=`object`||!l||!(`onEdit`in l)||typeof l.onEdit!=`function`||!(`upload`in l))return c;var u=l.upload;if(typeof u!=`object`||!u||!(`item`in u))return c;if(`isImage`in u&&u.isImage){function d(e){if(!valenced.react.React.isValidElement(e))return e;var t=valenced.utils.discord.lookupGeneratedIconComponent(`PencilSparkleIcon`);if(e.type===valenced.discord.design.Design.TableRow&&typeof e.props.onPress==`function`&&(t&&valenced.react.React.isValidElement(e.props.icon)&&e.props.icon.type===t||typeof e.props.label==`string`&&/^edit image$/i.test(e.props.label))){var i=e.props.onPress;return valenced.react.React.cloneElement(e,{onPress:function(){r().catch(n).then(function(){o||i()})}})}return e.props.children?valenced.react.React.cloneElement(e,{},valenced.react.React.Children.map(e.props.children,d)):e}return valenced.react.React.isValidElement(c)?d(c):c}if(!(`isVideo`in u)||!u.isVideo)return c;var f=u.item;if(typeof f!=`object`||!f||!(`uri`in f)||typeof f.uri!=`string`)return c;var p=f.uri,m=l.onEdit,h=`isVideo`in u&&!!u.isVideo,_=valenced.utils.discord.lookupGeneratedIconComponent(`PencilSparkleIcon`),v=function(){try{if(o)return;if(i??(i=b()),!i)throw Error(`MediaUtils: the React Native WebView dependency fingerprint did not match this Discord build.`);g({item:{uri:p,mimeType:`mimeType`in f&&typeof f.mimeType==`string`?f.mimeType:void 0},kind:h?`video`:`image`,WebView:i,emojiPicker:a,onEdit:function(e){o||Reflect.apply(m,void 0,[e])},reportError:n,isCurrent:function(){return!o}})}catch(e){y(e),n(e)}},x=!1;function S(e){if(!valenced.react.React.isValidElement(e))return e;if(e.type===valenced.discord.design.Design.TableRowGroup&&!x){var n=valenced.react.React.Children.toArray(e.props.children);return n.push(/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRow,{label:`Edit video`,arrow:!0,icon:_?/*#__PURE__*/ (0,t.jsx)(_,{}):void 0,onPress:v},`media-utils-editor`)),x=!0,valenced.react.React.cloneElement(e,{},...n)}return e.props.children?valenced.react.React.cloneElement(e,{},valenced.react.React.Children.map(e.props.children,S)):e}return valenced.react.React.isValidElement(c)?S(c):c}))},{returnNamespace:!0,max:1/0}))}var S=/\.(?:mp4|webm|mov|avi|mkv|flv|wmv|m4v|gifv)(?:[?#]|$)/i;function C(e){return typeof e==`string`&&S.test(e)}function w(e){var t=e.replace(/^(https?:\/\/)cdn\.discordapp\.com\//i,`$1media.discordapp.net/`);if(!/^https?:\/\/(?:media\.discordapp\.net|images-ext-[^.]+\.discordapp\.net)\//i.test(t))return e;var n=t.indexOf(`#`),r=n<0?t:t.slice(0,n),i=n<0?``:t.slice(n);return/[?&]format=/i.test(r)?r.replace(/([?&])format=[^&]*/i,`$1format=jpeg`)+i:`${r}${r.includes(`?`)?`&`:`?`}format=jpeg${i}`}function T(e){return typeof e!=`object`||!e||!(`uri`in e)||typeof e.uri!=`string`||`isGIFV`in e&&e.isGIFV?e:{...e,isGIFV:!0,embedURI:`embedURI`in e&&e.embedURI||`sourceURI`in e&&e.sourceURI||e.uri,videoURI:`videoURI`in e&&e.videoURI||e.uri,embedProviderName:`embedProviderName`in e&&e.embedProviderName||``}}function E(e){return typeof e!=`object`||!e?e:`url`in e&&C(e.url)||`src`in e&&C(e.src)?{...e,format:2}:`format`in e&&e.format===2?{...e,format:1}:e}function D(e,t){var n=/* @__PURE__ */ new WeakSet,r=/* @__PURE__ */ new WeakMap;e(valenced.modules.finders.getModules(valenced.modules.finders.filters.withProps(`type`),function(r){typeof r.type==`function`&&[`GIFFavButton`,`MediaViewerOverlayButtonFavoriteGIF`].includes(r.type.name)&&!n.has(r)&&(n.add(r),e(valenced.patcher.instead(r,`type`,function(e,n){if(!t())return Reflect.apply(n,this,e);var r=e[0];return typeof r!=`object`||!r||!(`source`in r)?Reflect.apply(n,this,e):Reflect.apply(n,this,[{...r,source:T(r.source)},...e.slice(1)])})))},{max:1/0})),e(valenced.modules.finders.getModules(valenced.modules.finders.filters.withProps(`addFavoriteGIF`),function(n){e(valenced.patcher.instead(n,`addFavoriteGIF`,function(e,n){return t()?Reflect.apply(n,this,[E(e[0]),...e.slice(1)]):Reflect.apply(n,this,e)}))},{max:1})),e(valenced.modules.finders.getModules(valenced.modules.finders.filters.withProps(`useFavoriteGIFsMobile`),function(n){e(valenced.patcher.instead(n,`useFavoriteGIFsMobile`,function(e,n){var i=Reflect.apply(n,this,e);if(!t()||typeof i!=`object`||!i||!(`favorites`in i)||!Array.isArray(i.favorites))return i;var a=r.get(i.favorites);return a||(a=i.favorites.map(function(e){if(typeof e!=`object`||!e)return e;var t=`src`in e&&e.src||`url`in e&&e.url;return C(t)?{...e,src:w(t)}:e}),r.set(i.favorites,a)),{...i,favorites:a}}))},{max:1}))}function O({color:e,style:n,...r}){return/*#__PURE__*/ (0,t.jsx)(valenced.react.ReactNative.Image,{...r,source:valenced.assets.getAssetIdByName(`icon-search`),style:[{width:24,height:24,tintColor:e},n]})}function k(e){if(Array.isArray(e)&&(e=e[0]),typeof e==`object`&&e&&`uri`in e&&typeof e.uri==`string`){var t=`videoURI`in e&&!!e.videoURI||`contentType`in e&&typeof e.contentType==`string`&&e.contentType.startsWith(`video/`);if(!(!t&&`contentType`in e&&typeof e.contentType==`string`&&e.contentType.length>0&&!e.contentType.startsWith(`image/`))&&/^https?:\/\//i.test(e.uri)){var n=`sourceURI`in e&&typeof e.sourceURI==`string`&&/^https?:\/\//i.test(e.sourceURI)?e.sourceURI:e.uri;return{uri:e.uri,searchUri:n,kind:t?`video`:`image`}}}}function A(e){var t=k(e);return t?.kind===`image`?t:void 0}var j={"Google Lens":`https://lens.google.com/uploadbyurl?url=`,Yandex:`https://yandex.com/images/search?rpt=imageview&url=`,SauceNAO:`https://saucenao.com/search.php?url=`,IQDB:`https://iqdb.org/?url=`,Bing:`https://www.bing.com/images/search?view=detailv2&iss=sbi&q=imgurl:`,TinEye:`https://www.tineye.com/search?url=`,ImgOps:`https://imgops.com/start?url=`},ee=[{name:`Google Lens`,prefix:j[`Google Lens`],icon:`data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAJyElEQVR4nO1ZfYxdRRX/nZm597237+0HBQHLh62m0QQRQgmgIQRKUSxIjUEFJBIgQoOIIDVKYrKS6D8SkIDGtCSaVIuEJpBWEQIUsBAgUAqx8mEFykekyC67ffu+7tecY2bue9vdbff1rRTKHz0vJzN37n1zf79zZs6cmQsckAPygYSwD0UAhXPPLSJNi8iyAEppfyNNGVqn0DrC4GBE69bZjw0BcX0sWTIfxp6QgY4jlkWK1BEgDEFQAti9JgZQFaJ3lPCrINoK8HN4cNOblD+wfwi0liz5VKh5JRHOFqFDAFQA0XvpmEHUAGSMhB5NxN5UeHjTyx8ZARkeVtj60FHc1NfAmqsAKeQ9ESDSY8cEKA1SJUD1Wdbl3ytlfoVg/I25Dq85EZArFgeoqYsl0ddKbI5BqhXEAZ9D59QGHgwBukSgwJEXCF4B4Rbo99bQunXJPicgV3x6kLP+mynR30ZiyhIbIDVApuBJTGPh6jSj8/yKTD8kPJRIl9qPcvt5N5uoAZE/I5q4nu5fO9ELLtUT+Bs+dzAKpdtVIJcg4DIMA8YC2u4yweTwERCpPfuEFGAqmA6ec3V1sWWILEXQfyx6FLNX8MPzBkDRLeDwAj9BWQOWQJYgzIB1L3Z26DAhiIibEbtwt4l54QyQrG07nu4BodcgvAIb7nhynxCQVQiQBDehlV0EIu297A3mwBOIFcRawLphNBOwr8XtG/lEd2BtDZIakCm3n5z842tQciHdc8ezvYLvSkCGoVAZugBxdiEUaW8w/z5vqVxZ5SQyC2IdAfS2AA8QsAHceAEbnxnznZ1++iAMPg8l58DG55GMLoBtlqD7ABUQyLwF8Aq65w9zAj/dWDMJ/K10JFLagDg4Hi0Dr40AqBugFgL1ENIKgCiAtMKtiPQqlen1eOSRd2aPS4CceeZhUPZrgL4KSh8PFb4ONbAC9925sdv/5k7gcfULpPoniLR2IHcjMFEAagWWyGygulqJezZv7xWAX73PPHUha/MDJVhLDz22ea7AuxKQJzAfRWxDRn1IFeBCZlMDTWf5AKgFwEQomCjehxFcSmteeR/7ScweW0vmWoD7EAh8yAxSILBA0Amf7Kg/ishcTmte3W/g9+gB2YrDkIabAFmUx/a2sgAp5UOpbt5Go7iMLhp7EftZzG4taeEEkPqED3nUIeDCtsB7RGcWhexOHNHcho+BqKkXIiAo8wUQueUSk4p26dJ7pd9HQd9LJyLFx0DMtKunUERZLfLtnZjvxHmiU1eyHdJ6vtcXLB0evTdgNhopjKTQwjBsQWAon0a4RZDBpFwSAlYaGTQsGWSkkam8tFDvJUI/furGwbHZCVQGixAcOXnth9BU8UPqQVrcu/UtqWVQCEX8Qg6GBSsF8u7mfBq6NZEI4iiRcv+BdSQcGQeeNJj0DgC3AuhCQIoBkB7krT/VA55MJ8mULZiDOAAOqsuOLKv2oi4g4V15oO+/7ZN26Qg4ouy94UoVWGUOmtn/dAKB1bBS3JXjT81V2q9j6yzRs7ihIGD/Uzq3fE5gunfZd++AUj6cPBE9ec1QRojK3Ql4c7jxPts21b10bnPXdsCIao95n6/6DVxHJhNxP4za2vZEp+7+wbI73ukNaWQhFM3odtd9bzX6JOYg1oPIN10OUD7kd884ZDLp7gB29TxI+muBCCHrToB0CknH8/6nrAHT3C0nAFjfKwHx7p8Jc0YijU59CrW2NybvEWUQdxjQbUdWr0Zg/o+zW75D8rskb0e/CZEMwvYrL96NsFcCTHqESbVVj9hJVSMWeRvDqZpgUuII56TbXnBjzSvSjDHe3QNfRITns20Qx1ZMxwsizv3iR3/EWNC/AMcB6Cl3J6Hz2e8lsxmva48G0b5ZMc4R4ZUg2qNxXBIT9mFHVwJ+qD0r/wBxHZAhd1RgBXBHBK1cZUJwcBP4+ubNeOHEHlbjLT+jp/f2zDE/lzAI8C0i5YzmjwgwLVr5WfTWszUz1pWAF2u3sKaRjGQoEcDN6KZTAeoCqgG6yvhOQ7AWwEvYB2IHd86nVL5sbEBaAuc1t892UyCv+rmgHsCNfkPb/VSCTsF/G5D1VQHGBHjflQyMSq4jDLwHHP0W49fXPwp3GvfBZFhU3Yxd2wxan22GMVomQaLZndaQX8DcQkg606Tu7flYZWeMW8eBxk4A454EefUkAIy4kmlpNSitvujxwd1Wx7lI5Yjnvh8H0ZWtIKLItBCZCJGJkZgEqcpgicFCTzxzA/7dM4GjT8U7VcHt4wx2BFxc9WXHI0KoIqQJLp9XlXmrT/r7SQunRMje5O67K+qPD12dmuiXsW4VEtNCYiKkJvJloiNkOkaqkjTT9ma/kMzlVGIc+F0EfLUBHNfIxz/cUVlVCDUJ0ZSyU1VD5RsxFz5z9Mblq5qb+jeMnvand2eE+BnAbykZCk5mji8X3VyeCVVUHiZzcaeM1sU8CyYLTcHjOslmDQSzWm1YoBY+g4sji9/UgUoNQE0IdQnQkD40pIyaDKAm/ajyAKoyFDXR96YI3SfMf6lT6QWctbqag/5mqTxvcBFn/adJOnS+zfqPkax/HvMAcVaGsSUEtojAFmCyAgwHMOxKM6Ezc8X26w5fN5sHurp91WYEO2P8tkm4tCak62LQkpIH77Qu/Z7AhFMeQIrAn4i68Ashtx41fBXSB1GKuQzOBsDZIKzth2QVuDbYPhhbhLGFnIQNnYq24Z07woWX4UpK/6+z0StPRNrUWFlj3NUUbSMUEUkRvvT1ELGESCT06a8TDz5fUxyTikAq/j3kJkkGohRECRTFIB2DXOpFMTKVeE2d6gSZTh8WsT/qBn6vBJzceAom6imua6FwVyQFTyKWgtcEBQ/eaSfxml1cPpkBTlUCckrtUsWAimEdcEeEoietaq5495pFI/vkdHr1GRhttsKrEy6uibnQcOBTCXNFAOtjQfv4fDIBy38d8e3kTn1zLzgiNI1AAlapZZ081TLRZdXvnby9F2w9EXCy7qzx6qHlw1akHPwwleCfiYScIGgTUJNgp4KeCt63k6WcQA4eyg2ntF0mo0BymwWfj0uWbvvQPjG56LThkS8d1aDSNS2Ur2pyXyGZkZxOAp5x7UrmEOw+A3Af2PZBnErpackKN2SVw5/GsmXug+BH85Hv8PsvWBAZc72FOpuIDmlPWD0T9NQSHAhzKRIu77S29FJmi7fZ5T/96x53OR82gU4fpY3fnW8sLRaNY0lkEQkd6T6zivvM6pMxiQlUI8K7YtUbjNLLsH1bGhL/C8tun5PFPwwCu8R9wVy8ozgQ2qI15EydeyNgVoizwkQpHh14vYUzHttta3hADgj2j/wPx30G4ArB/t0AAAAASUVORK5CYII=`},{name:`Yandex`,prefix:j.Yandex,icon:`data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAADNUlEQVR4nL1XPWsUQRh+ZnaNmlhscZjKsGoRm+CZLhiIQqIi4l2wMhYGBDvx0tnFYGWlh38gFtpJ9rARc6KBBKw0YmOlh52SYgvvSO5jRt7Z2w9v9/bjDHlg73bZmfd53o95d4ZdLl1DGryxdWMXzSIHmwFkXoKZgDSct8xmkDWAbQvIjSMYsq4YbTuNXZYkwLJ1U0PrvgAWfcIUhsFWBQ6tFI12LW4cj/O4YssnDM0fArKUhZwgIRdpLtkgW5kEWLZu7qH5GYr4fyFLZItsphLwyhZ5huZ7AJETBoRJNl/bIh8rwLJ1UwfW9pncEyGAtd5IcPeG8hTlOcuN+tfwSCILjQnO6RVBHMGa0N2bPbSWozzX7yyBn5lQ9+LbV7QeP4gVoN28C2161hn/6SNazx6FRDhcbMmLgBOW6ILrVF549ySEdcVEep8b9cgJ7XWrz0hZclPBnR/lfSTIa7pc6IVbfQVohQWfYucXZGBeSCyaymFO+aA123dkVBTGTocN5kbBJ6f8OdbLOJNgwG3i5tReY0d2oyB3fnvP2tz1sEES1i1S8r6zVY21KQGntXPV25PReevnU5ucCq2IYGqSyF1wYIZLIJ9KwFYVslF3HoZHwOcKvqHpWbDcce9ZbL5LJYC4eeqm06hDBKKgXyp6UdDO+5Xf2ayqFKQBA0ye5SPTXq+EosDHJ7w+oQRU4ouvtw7Y7uJVmXqGyvUCtGI33406msv3vPCTOPnzexZz4LSZyDKBouCB2u74hNcrspIzwKYaiN0whNCoqzy7CHa+rJBAjUuIL1knisAyS2rPcWDANqXgQ2YBPe2Znzg1kAABbHDaQGatA0JwqbGxwQQQN6fdq4B8jgMGA1aJW30NGcTTgxYgIFboXwkoGnpNAOUD5C8TpyeAcBRDDzMvycFQO+xwhQ8mlt02GXiqHbH6Dgwfcx4af/wWnUAuIS663hP+2RXTizYwnyYSqu3SroeulORkO0geEkC4YfBtUrnP6VCek+1UJ6OioVOezu1TYZbJVq/nsQIAgNbovMFLEuKkzNwnVGMr09yCwUtxJ+XE07EL93gOyAsM/KxTqP7xnMJMvT3r8fwvuzxdt4ZeDa8AAAAASUVORK5CYII=`},{name:`SauceNAO`,prefix:j.SauceNAO,icon:`data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAcklEQVR4nKVTQQ7AIAiDZv//MsuyYBbSqhMORostWsXNLKwR1zNEnGm4+yuQiz+RRVHB2WlYHqw6E6lYcsDASvjOazFnr6CuwXzC7kZlMqwZYOCOiVIgimHKWCoQwu2ZCBi4Y2JyxldWxFV+CBw3VLedb0flPxp+MBwRAAAAAElFTkSuQmCC`},{name:`IQDB`,prefix:j.IQDB,icon:`data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAYtElEQVR4nIWZB5Rc5Zmmn3vrVs5dXZ2DultqSY1yRCJIRGGCsUwwGNAcE43BmDGe2TFYazMGvIw9u55gwHHW42GObYLBAyxJhkECJFlCoZUbdatbXZ0rx1tV9949/18t4fGsZ+/RPXW6VPXXF9/v/d6rvP7qv1mH39vGZbfcw44de8if3INeqTCamqbRH8Ztd4BlYVkWiXyWqUyGkNtLvd+PTVEIetyEvR58TgdVq8rAxAQj0wkM05TfAQtVUbEpKi7NLm8UyBZKLF+useXKTlAUcDVjVUvEfv8hjSEHu0+X2X0gzs5BhVsvXc7OwzEafT52D53k/s0bWXPhhajeOrRtr7zMqtVrCQbcpAZ2oykKiXwGj935H4yfyqQolqvMjTaiqqp8z6aq5EslRuLTFMs6Dk2j3udjUVsb2WKJ0zMJErkcOb2EYRrYVAVNVfG7nCxbGOC2Kzukg5Zlsv+jA3y4N8aqSIXpKYVzFzXzwjtjKLjZtnsIwyoTzyV58t4baFmyGsXuBNNCc9lsXLDpU7zy3K/QgHK1Ql4v0h6O1iJoWZQqZZx2O/W+gHzvzF0ql8nrOh6HE4/dJd/LFsoUSxWaQ0E+tXQRuVKJ0XiSsVSamUyGmWyGrnYH997YKRLB0cEEg0diUCzwZ4s92G0uxtNV3t83xsouF7mjTmKpGaYzWW65aBUHYwXeP/k2erWC1+dBm9u3iPjMDDNDgzKi2VKBoNsrUy6MF5eImsPpni0JzjogLo/TSa5YIlMsUiyXMC0T0zQ5EjtN1TCp87uZ2xhlblOIkNvB+i6DWy6NcPrwMCOTeSr5IhGXwoqFXs5cLQEbLQEFp1Xl+WyaiC9Agy/ER0fHODgwTsjj5tDpMbw+L8qHu/dZv9/2OoXJmDRYeNsUqENVlP8Q7T82/Mxr1TDkZxWRLCxMy0IR5aUo1Pm82G0qg9OTJPNpblwO5/e42DuSJ5as0hKy0dfswOtQMUwYnKlS8dZTMQvs2BPnSMxBsSIqokRB1ylVqvR1NNLVFGHBnCYaWzvRJlI2UrFhHDYbFaOKQ7P/l8afuXMlnXKlIg0W3xNlplfKMgP1fhcd9XWkShkmk1ncmoMLeywWtTr4191J5jc6WD3HSbwEp3QnquLE7vPSs2kFTk8YK/YBtnSSnUNJ0nkLn8NFxBvEabdh12zM7WiiY04X3Q1BlCf/5hnLivXX6rdUlCghSukPo/ynnFEtC/PM52bvsmGQyhdqZ9ltsgdyxTwblvhwe+zUOUzm90Zpag7SXO9GMQ1MvYTisINNlX1hZnNUT51iV9JJ/ZxWQl6NiE9BVS2ODGUJ1F9BR0MEnF607NjHeGcNUxVxhvqfS8YSDW/KxhGRFo0u6lzcCjVk0VQbesXAqdloCPhY2NJI0O0m4vdK347FxjkWm6beV8GhJGkmh5G1UTJgfKZAJl1AtWvgdKJgMTmW48JFGgMzUzSGI6BXsbJZFjcF+N3gXubMvVXaqGz94p2Wx+GQhp6p5z+OerlapVDW0as6q/qc9ASr5NNFErpCbLrErlMVor4wvU1R2uvqqPd7GU2kSOXz0kGnXcOpaYzGE6QLRZkpgXSWmWJ5e5nuejs+p4qKhaYqlCoG9X6V0UQFt10h4LVT0A1CTmgNaUwVFeIdW1i2ZDnKE1++1/r/Nap49fiqbNncSNRvw0wksDwe3tyXYfuuDIppR1NqmRNZcTnsXLigVzbfoZEYg9Mzsk9Cbnftc0CmUCBTLMiMRTxZrlzkYH2PE0WgAZYspXLFZN9IkYKzjw3LlpIt6JyeHMcwpsknhomuvR3l8fu/aP2pWi+VdcpGlWjU4suf78ZFFTNfIKk4+dkLY2RTmvwhMczSxQI+l4NlnW20hOp488BhJjIpuqMRQh4PU6kcJ6cnZXk0+oPSCRWBUBN4HHZUNFpDcOmCCi1BC82mkC+ZHB2vsHvERUukGZddQ7VZROv8OIMhLK2C8th991j/VaP6/Ab33tKOxw5mucR41uDJnw5Q0VVsov4VG26Hg4phEHA7GE1OEc8WJXIE3B4mUxlQKlQNi6ZAiFK5KqFaOGVZFvXeIINTU6AYBJxeGoNBptJZCb8+l12WtThbIJz4WwDD0FRCDlaH3Y72p7A9U8xjKCW+dOc6PJE2KI6Rzpf59o8OkkhV5BgXnxMlo9lUOqNh3A4PXruf81a2y5nwyp7jOG12Ir4wq/ta2d7/MTldpyMcZWBiDJfDRr5UZE59lJlMlnQxJ+lIY9Anp/zHE5NEw24iAQ89wQjdTRE6oiHmt0WJ1NejuLz/2QHRsHpFl6Vx1+cWEm1fClYFU0/w98+eJJ4oE3BprGivp70+iM/tomxBPF/inYODJLMFinqJpX3dPP3QFp56/k32DIyS2Ktz82c3kRob4bltu+mIRBmYHBfIiWVO0RgI43O5GEsmcNs13Jqdhc2toBp8euNKNlx+GVpVx4ydQHH7sHUvk/Yq37jrC5bdZjtbMsosti/otXHTVe2SaIHJa9vH2fF+DkWglFll2cJ2Lr94HcFAECwDq1TAyqU4MjTKa3uO0j84xeqVy/ji9Rfx0BM/4PDQGPO75vDQfVv4m+//kA8PnURTNdzOGurVeT04bA5Z5/lShZZQEDHeRdPn9TKJks6G81exsD3C/KBC69qLsbtcKF/d8nkr4HafHUQlgfXVAo8+MA+f2yYPn0npfO9Hp7ErGsVyWQ4p2R9eL5s3b+LCdatqjgkelE9jJSeYjKf46395i4lEir9+YAunDh/g6z9+iXRel0Gp/ZwlzxfNX+dz0hAIMJnK4naqdETqsUxLwnfEG5CfG5qakv0gGPmqBd1cffmFqH6XC8RQsizSxTxT6SRrV3jPGi/i88Jbp5lKp8kWC3JS13v9kv+3hjW2vfoGP/jZL6lUq5LXK74QexMGT/7yLea21nH3lutIJpL8z+feIZPXcSoWmz93N//7ufe48yuP4/WFuOMLtxIKh5nMpAl6XES9IblXCP5T5/EzkU6QKxbobmjA63Th0Rx8cPAEX3niKZRv3fUFWSQyGqZJspjh2w/Ok8NDQLKgx9/8/pDcDwQSiM8JviRem8I+Ll/bzdv7jjOm21izYgnbd39EV1sz115xMe0NdaRjQ3z6y48zMjGDiIlTNXE7FO79i63cdvsXOXFyhPndzUyfOsp/e2Qr/QcP09fSRqVqcGj0NA1BL511UblI6dUybeF6huPTfOaCxWxatxTVnDVcL5cYS8eZ3+Mh6LWjyuwavP1BDIeqSbSx27Szxou7qz7KP71xgOXn9LKgo5H+E4N87+Evc98Nm2SD54sFnn/5VYbGZ3CpomxMdMPCMg3effabPPPdrzG3qxVFtRPt6OUnP/opV3/mM5yansbjtLO2pwenzcmx8RghjxcsG/tGhuTS5HH7mLt0BZpo2lpUHXLsL+62y1oWMGiZJocOF1AV91mUEluV8M2wDMn5qRj8bt8p/urOT3NiMsvkRztoCPlQOs/BZhkcG5lGU8yz3xcBi+ctbJrFdZfOxTKqnD49TDjagqW42PrIVna8v5MjsRHqfX7q/QEE1RmYjNHT0CT7YnByiufe3smJpF7LQLpUkA3sd7pYHi5h5nPyB08PzxDP2MjpRdkfgg4I/L+kbz5XL13CwPgUw/EpEuNTvPjv/ZzT20W4pV3CnGJ34Q7UEWxspj7ayMNbv8ncuT21hccyefewSama48AvruNvH38YK5+glEuhWgaPPPx1li9fSdU0ODo2TDyfkrYdG4sRDXhkU+eKOu/v2IkmIl0QO6tRpbNBw1kuYUxMoPZ0s//gDB6HB8vUSBby9E8ME3C7ZIM3B+poDdXx0dAQI9UpKu98yMqVi5nXNZc/vB780h24G+bx25deJn76BJf1WeQ1H5s2NqDEX+LpF6d56KtPkBaLlFbAqjg5d+Vyerva2XLzLbSGI8xkcgRDdlSbhyOxURY0t8mAJnJZVENQAKebiVSCsD0tMd8ql7F0nYMnU0xn0zL1QZeb3sYWoj4nJ6di/Hr3LqpGlbmNTWQKJcZTM/z8n5/njy+/x8VDt17GL59+nC995Wu4/WHuOL9Mi8vBj5938/jWv2V+eyMtSlbuF1R1XHqclrYO1q5dSaqQk4uMW3XzlzdcwnPf+DMyepbWUIhnHrheMlgMy8RpdxD1zdaqWDKSSSbTdhK5jGSNNaZpYFM8zI3W0VnvZf/IkKQc81ta6elu59jxAfYcOPKJ9QLfTPEDBraqzq2bzuOxb/+MZPgBpqoX89/v+3MipThWrhakMzs4lSLkp1lz7hrq3D7CXi+9c8J899fvMBCb5ju3X0lGz/HKh8dRJf+3wOtwEnCJM0wJn5npNIWyQ6oT09mUrEfB6atWiaOxLNevXcCVy3s4nZgmV8gTVGDd6oXs+GCPPE8aLv6ZwgkDq2pApYrL0LnmvJVcf+kFWOMnMeNj8j67UYlbCAp6lvUrzmFSCZDM5dDQePavbmb38RFcTgd/edMlHBgcRRWTza7aJAdy2eT0lldsMkeykJH/1xysI5nPSYHK7/RiUOTH2w6z+YIVPHDNesbTCQ4NjrFhQTuWJDezhwhqYlpYYmMXDlSrNUeqpkg7amMXNoFWLd1gs6GIlVLVBM8W8gD1YR9dc3u57car2Lb/ONsPDbL1povRFFi+bAGf27gYtVKtEEslpIpQNWtcSLFMssUq5UqZeD6Dw6bJTUuwzzqPF7Nqyag89epuPrVqAQ/fdAnxXIYXtx/gjmsvPlM/nzBcmYUztyG5k64XpU6keEMoTjeqpkonLNXCqtEjGYDPXzCHW9Z088wDn+Xnb++hoFfobK6HYp4brr4INZaO0+APMpFKEc8ZZ5Wy6qw0KKiFUN0CLhfntDYTSyZpC0cIOBR2Hf2Yd/sHOb9vDl+96XK295+gqtprPz5rRG1DrZWpJRFuCHNqBIdZxTAqsmRMVWHXwaOcio2f5UeKJaQaBZ9dxTIq9DTX8/27r2H7oWGEhwJU0qkEmljU47k0nZEGjk9McUWfSyLRmQEnjhN1Lkpp/jkN5Eu1nsiVFdoiPn6xbS8bl/Rw2ZI5TJibeW9vP9devvFMAmqOiLoWp6anscQtspCcoHHeclBVXn9pG0tO5UgXi7xplrCd08EF114ia123e+kfnmBxa5jWSBibKDFJflSafV5UYahAkopRYTIbISaWFcAtNrDZHVesjCenxjg6HsMwq3RHG2R6P7V8Hm2RgESGnOpk2YIenvjHn/ObN9+tRV70o6LWmKqqoHh8KFpNQJDTPptAL1dQ953Cq2l0zOvkgnNXss4b4dgb27Asg3AwQO/6i9kZyzM6laAx5JPTWJSiACBVkDRxTaYTFHSLH75nZzpbJeBWJaGSOwKQK5XZNzwk10GhKDQE/Dz3/jHuv2Y9TpeDMXzc/OePEW5bwgWXXQdqbV+WnkhkAcUVQAlGUdwBFKdX/t/+/mMsDdShtUTQmsMoLjtaZxu9kTnkJibx+zzSjvMvugS1axm7xwoMjE7JshIzQ436Q2c5ijAup2v8w+80uSmJ6SwdUMTC4cWGSqaU5dX9B0kWssRzOf7+5Z20LFjCM8++wtR0HLOc54O9+6jUzYNwpxSfzqbDpqCEGrA192BrX4gabpbrqChUW9h3dnyYqZRELZflxVIdpDI5mfG2libWbbiIyNLzOFIJYrqDqE7Njl2tMUyh6Qtuk9XtPPWuHYet1sg11S7PVcuXUimLDakonxUUdZ39J0/zg19v49/eeg+HYnFyz9tsve82Lloxn63f+hajRQd4I7P7gh38jeAKYim1LXDFovns9Qhkqg1R2Tt6WUKuGgqQzRcoFEs1aBaQbJo0hEMsWrwY25wlAnGRfEMgXM0Jg+H4JIWynai/UaoJ4n2nXWHXySNyDQw6/XjtmlQYhPbz29feIpFKy7Eu6bll4arGWR/aQVvHHJ5/+QU+2H8ExRdF8UTB4QHNCYrQNRQu2nI170zGKJT0TxTx1jpsHpP9B/oJBUTdi9khjZytCoVcclr8piUnrJCwhRx+RpUQTgji1tPQKOFMLBb9w5OS1moaNAejrJ/XyufW99HRUHtuIKJYNkym8ybHpyx2jrZQKRxFO/0TGRhUG5TSUC7IklJEg1vg93u5ass1jLd7iDco2Ba14ehtYXpoALep0xKpm53sYkbNDkjLIuAL1DIg3hP7qFhWxGQW5EkIS6dmJmX/rZvbS50rJJvJhp3xZFpK5sPTeQYn8py/eunZPjqzW1erFj/8xe947Sc3Yyl5vEIHKqWkAyJ6tR2aswNP/L14UR/tixfj8EL6+F5eeuFlblw5B0uUn6TyRm0YnoFooaTPqloylT3RJhRLJVcs0xDyEPI5SJXSFCtFlnV0sqCpXQq8QkEwqwKZcuweGOLFN96XcCsmuTi8paW1pl4r0D03wInBLI3ROjlfanxHxE1k28CaRShpRi6JcfIjUod38+Lr/85tG5ZgFXJQqUhCeHaan6UqJlpNYT6zbanMb26Rm9bIdIbWOp9MfYUCU9kU16xYgttu5/DoKGVDJ+z00dtch8OpsvfkqHRiV38/t1+3id4+uP9GP+2BOmK5ZrzNXZi5cdRyuRZJQdsV0bBgZEwopLHyKcYTWQbG4ty6YSmWMLqsY+k50MSAFb6asgStigl6DuX6Sy+wWoJhTBE9LDlxBYQeGBnGoQmNUpV/i5hZhsaarm4SuTyHR8eYyaVRVJOIx8/BU2NMprOsWHkuWrWIlhtg/fw8w0k/vYuu5P4vPYh5+gC+5IiMYE4v4/O4UOyCxAkWCXsGYlI+XDi3CzxBFM2FWSqheEJyrhSyKfRSjmo+iVot4nU5UO659ipLQGeDPyAJnXjEesk5C8mXdN7s7ycQMJicETCG1P+Fg+3hiHyCKZahWDJFsVIg6HHw+r6PZSAWr7qIW+74Kles7aI1tRc1NUa683wi6ZPs27OHoyMTXL64Q05VUVITqRzxdI6exgAuESnDqKGOaq8NPU+o9upwg9sjheSxxAyeQATl9quvsIThwgkhdbvsdkyzSmMgQGPEwaZz4b3tQ/yfowbl8iyMYRL2+Ih6g7XHUSAf8B0cHmVgfHq2/hX+7u5rcdogmdMZnIhz+PQkN21Yym0XLZeZVT0BnvnN27yx9zid9UGag24+u6KbroifcsVgJJlj/3CcnuYwK7pbURxOxm1ePEsupT4YkEuPNqchxMi0eG7VwsmpKXJGQSoPoubXnxulscGPblr882OrefR/7aL/tCklblE+YluL+oKEPX7cdidre7rpqq9n79CIhOIXdxySKl5HxMtly3p49PMb5ZKvozIeGyTa0cfBoXH5YDyVLXLc7uLdQ+Myu2I/Cbjt3H1xH53REMcmk7g7e2hZuQmv3YKCIIUmynWXnWdtnL+APYOnWNLWzsmJKYrVHMVqiX98ZBGl6STjR4exdXbQ6y7ynV99zKHRKuOZGnqJQ1TFRp3HJ2UQ8ahJ4Es8m5MU3DDLLGwJ01TnJRL04orWg6EzJ+Ag0NXHrX/xJKlCCb1SxZCKt8W8hhBz6gM0hbwcHU+xrHcO9911C6GexfK7Z6BaLErKo3ffYB0aGmN1VzfDM1NcuWQJY8kkJ5IDPPngQo5/eBR3pcB0SWXu0k7Kk1M89eYU9fYyr/SXiOdrLECUlUDEgMsry8vnnNVb/x9XTQU35CNUQV/Okj7EQ8KK3D8sq8KVqxdy25UX0rx0DYrbXxuEnxwitzvlkds3W5tWLuD7L74rty2RzmUd7Zx/noOrVnnZ9XY/nRGNkEvhf+yqsvUzTYzj5+Hv9XPPeoWPExX+ZXeRZLp8Fo7FJZo95PHJW5SEeL9YKZMplsiXSzVuRG34iXIJeex0Rnwsaq5jTU8Tq+e1Y29qR22bj+qvk7K9mNiaQKxZBwS1UI+NzrBu6UK+dv1GSdACHhc7Pz7Jgm43xnScsbTBhBaUs+f93afZe6pEe5Of++9cxqOv6ZRLKq98ZwUPb/Lis1ckP5IRNqqyj05MjnJ4fJhT8Um5d9htipQGG4MhvA4PbiGA2V2s7WpjTc8cfNEWDlUD/MPhDFt/s4t7Hnua7/30V8TTmU+M/wOaruUKJTLhDtYsgXsKOt/+1zdoCLvoafVROTTCaNJEmyywqM9Pb6OTh392jLdXd7B2eS8P3lXlu0/vYaw8zNcvDnJRr5Nv/DbH70/Vyilf1uUMERM3YxTICAXwT1xvHh1EOSqUSiHx2Fm/rI8rNq5jw7krcIfraxB6hpbLQWjJia6JhCdzRcLtC7m4Upbb1WRhGEXUl2UxnKiwuKuMGmpiabuPX+2K8fL2UTZvtHHV5tsYj5f5p2c/Iujwsr6lwiNXevm7bWne+1hhQVMzliXoty7rWkgzVbOC22FjPJWbfaCusKGvXYq+uwfGZMndftU6Nl91CcFoM4rAeptWk1rOXOJ70gn4v/KaLFEhQvTFAAAAAElFTkSuQmCC`},{name:`Bing`,prefix:j.Bing,icon:`data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAABhElEQVR4nO2V4XmCMBCGv0sXoBvYCeoIogPoBu0Elg2EDSxdQDdoB/CBEdigjpAFyPUJookVIdS0f8r36yDh7uXjcgCDBv13kevGIMomUOUCEHMAo/p2AeICJBK5Dve/AhBEWQDGCsxReyZe1yDSG0CgiyuVA/TomK+AoLAPhGhd1W9uF2fkugAE3ct0SlUMbK0nxmC1gg8HgigbQfGnRZPIdBY37l3uYoBM4YML+W0OqNIUI9pcK65VrWl3Ts+qhUvxdgAIYz2d2dysO0rMBc09AGB8DBztLKx45APg/DR0qO/xcwHYN7nROqia3fgpAH+cwpK7j5Yqn08xkQcAId5NQkyCZXYV4rAmnqz9VkPeMgmXuzVAL2Y3b0Biq5uy7otx5Q7B2M/I5ds09DiKOXPpgW9pY5mGyc2nQOrOrsYtv3ZmsgcROG77ZM4ARwiZziIIeqjnvt1g+wpOj97Kdk76QhA86+K/0PE5hG+Awz/D3QnhG+AaxJ8CXELYMIMGDcKZvgC3Ap03OJtkkAAAAABJRU5ErkJggg==`},{name:`TinEye`,prefix:j.TinEye,icon:`data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAADN0lEQVR4nG2RW2ibZRyHn++QQ7tmSXpI0q7NUqrMulqz1NbuwIa4Fb0ou6j0bjiwg12IMNDdOEWvauucghceQMW7ilQ3tKBOtm5StnWOSUiE1rULa78uS9PTl6Q5ffleSco8oA/8eeH983veH7zSkdFLh4SsjrYV7/RoFj8F2cb/IUoGdquKoijkDZOiYU5LpnG6fDM2KF/19elfcyNRx+ctbyGQKiGXXWZ2chwtcp3c2n1sioRUMtjd0c7eY6d7DJt7TJUk2Vef/JW0nsQlzEq4HG/32Dh/9hSx36b+apECDrR72XXkeSILc1TJ+NTy4kvXSaSIybZDJ/A4bASbrVz76gN2aVMMdIG7xo69xkGNTcHy7AnCTw7yyOYq+VyWiiCrbGOtrpsel4vWRpnrWpyuZw4SOuAh42wlZdrQizKJVI5ExkRMTyBLoErylqBMW0eIYiLCrDNIW7OP+cgCV6NZVrQfWL2/gL78gB07AzQ1NnJz6gpZfR1VVf8W+DwNJPQsHjPPT2+/RoPLhbW6mpsXvwNh4mzw8uknH9O5u52x8fO89OIxSpks9J37RZTnzQtRcWrilgjseVp0dAZFOpcXZUY+/EggK2Lf4efEPxk8PiTKvysLISiVTPIbK6zE48TCt+nu3UsupROLxXj15ZN09e4npetcm57mhYGBSuOj/f2VU9bX0qTW08QXF8hk0tT6W7l7d56R997njTNnkIHQniCzkTDRmTuEQqFKMLu5uSUQotwE4qKBYCBA7/FXmLz4I+sbOiPvDFMoFPg9GiG/mWZ0eJinevdx6fIk586+i6uxBann9YktA7D/MQ+1bfVc+f4blsPT9PcdRovNc+HbcexV1Sj2ampbWnE3+XE0tdDU2fNvQZmDj3sJPOplqWiSSCYpFQs4HNux2KuQVRXTNFEVBW+VFXkj/V9BGbtF4Qm/k2afE4fbgamAZApkYWLkiiw/SLKiaSzN3EZFCA1J2vEwXFdfw063giWXZHXmD+bmoywlVpAVBaNQoFA0mJuNcm8mjDANTRVmaQhJ+cJqU31d3X58PgdIMoZopaCv4VCz5H/+jBv3sjjdbrTFxYdvxbfD0J+SvGqetTDsMAAAAABJRU5ErkJggg==`},{name:`ImgOps`,prefix:j.ImgOps,icon:`data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAg0lEQVR4nKWSiwmAMAxEc5IJBOdw/zGcQ3CFiLTFtNo0oQ8K/STHcSnIRgbvhHGxpQFifdya2lPLd+BxSasiMQGRtwH4WmJPUBZLMrUHWqBWFoggV1qVgwnA0bG1cNmUHEBHlbxbQPM3LreAqIk8bnLcooPTzIbo+crZzdq5d/xEM5AbzjQbJbDBE08AAAAASUVORK5CYII=`}],M=`wolfie.media-utils.search`;function N({uri:e,reportError:n}){var{ActionSheet:r,ActionSheetRow:i,BottomSheetTitleHeader:a}=valenced.discord.design.Design;return/*#__PURE__*/ (0,t.jsx)(r,{scrollable:!0,header:/*#__PURE__*/ (0,t.jsx)(a,{title:`Search image`}),children:/*#__PURE__*/ (0,t.jsx)(i.Group,{hasIcons:!0,children:ee.map(function({name:r,prefix:a,icon:o}){return/*#__PURE__*/ (0,t.jsx)(i,{label:r,icon:/*#__PURE__*/ (0,t.jsx)(i.Icon,{IconComponent:function(){return/*#__PURE__*/ (0,t.jsx)(valenced.react.ReactNative.Image,{accessible:!1,source:{uri:o},resizeMode:`contain`,style:{width:24,height:24}})}}),onPress:function(){valenced.discord.actions.ActionSheetActionCreators.hideActionSheet(M),valenced.react.ReactNative.Linking.openURL(a+encodeURIComponent(e)).catch(n)}},r)})})})}function P(e,t){valenced.discord.actions.ActionSheetActionCreators.openLazy(Promise.resolve({default:N}),M,{uri:e,reportError:t},`stack`)}function te(){valenced.discord.actions.ActionSheetActionCreators.hideActionSheet(M)}var F={doubleTapZoom:5,rotateImages:!0,rotateVideos:!0,zoomEnabled:!0,fullResolution:!0,favoriteMedia:!0};function I(e){var t=typeof e==`object`&&e?e:{},n=`doubleTapZoom`in t?t.doubleTapZoom:void 0;return{doubleTapZoom:typeof n==`number`&&Number.isFinite(n)?Math.max(2,Math.min(10,Math.round(n))):5,rotateImages:`rotateImages`in t&&typeof t.rotateImages==`boolean`?t.rotateImages:!0,rotateVideos:`rotateVideos`in t&&typeof t.rotateVideos==`boolean`?t.rotateVideos:!0,zoomEnabled:`zoomEnabled`in t&&typeof t.zoomEnabled==`boolean`?t.zoomEnabled:!0,fullResolution:`fullResolution`in t&&typeof t.fullResolution==`boolean`?t.fullResolution:!0,favoriteMedia:`favoriteMedia`in t&&typeof t.favoriteMedia==`boolean`?t.favoriteMedia:!0}}var L=[[`rotateImages`,`Rotate images`],[`rotateVideos`,`Rotate videos`],[`zoomEnabled`,`Pinch and double-tap zoom`],[`fullResolution`,`Load full-resolution images on zoom`],[`favoriteMedia`,`Favorite images and videos`]],R=`wolfie.media-utils.options`;function z({store:e}){var n=I(e.use());return/*#__PURE__*/ (0,t.jsxs)(t.Fragment,{children:[/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRowGroup,{title:`Media controls`,children:L.map(function([r,i]){return/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableCheckboxRow,{value:r,label:i,checked:n[r],onPress:function(){return e.set({[r]:!n[r]})}},r)})}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRowGroup,{title:`Zoom`,children:/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRow,{label:`Double-tap zoom`,trailing:/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRow.TrailingText,{text:`${n.doubleTapZoom}×`}),subLabel:/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.Slider,{value:n.doubleTapZoom,minimumValue:2,maximumValue:10,step:1,onValueChange:function(t){return e.set({doubleTapZoom:t})}})})})]})}function B({store:e}){return/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.ActionSheet,{scrollable:!0,header:/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.BottomSheetTitleHeader,{title:`Media options`}),children:/*#__PURE__*/ (0,t.jsx)(valenced.components.Page,{children:/*#__PURE__*/ (0,t.jsx)(z,{store:e})})})}function V(e){valenced.discord.actions.ActionSheetActionCreators.openLazy(Promise.resolve({default:B}),R,{store:e},`stack`)}function H(){valenced.discord.actions.ActionSheetActionCreators.hideActionSheet(R)}function ne({api:{jsonStorage:e}}){return/*#__PURE__*/ (0,t.jsx)(valenced.react.ReactNative.ScrollView,{style:{flex:1},contentContainerStyle:{paddingBottom:24},children:/*#__PURE__*/ (0,t.jsx)(valenced.components.Page,{children:/*#__PURE__*/ (0,t.jsx)(z,{store:e})})})}function U({color:e,style:n,...r}){return/*#__PURE__*/ (0,t.jsx)(valenced.react.ReactNative.Image,{...r,source:valenced.assets.getAssetIdByName(`SettingsIcon`),style:[{width:24,height:24,tintColor:e},n]})}function W({store:e}){return/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.ActionSheetRow,{label:`Media options`,icon:/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.ActionSheetRow.Icon,{IconComponent:U}),onPress:function(){return V(e)}})}function G(e,n,r){e(valenced.modules.finders.getModules(valenced.modules.finders.filters.withName(`MediaShareActionSheet`),function(i){`default`in i&&typeof i.default==`function`&&e(valenced.patcher.instead(i,`default`,function(e,i){var a=Reflect.apply(i,this,e),o=e[0];if(typeof o!=`object`||!o||!(`source`in o))return a;var s=k(o.source);if(!s||!valenced.react.React.isValidElement(a))return a;var c=a.props.children;if(!valenced.react.React.isValidElement(c))return a;var l=valenced.react.React.Children.toArray(c.props.children),u=function(e){return l.some(function(t){return valenced.react.React.isValidElement(t)&&t.props.label===e})};return s.kind===`image`&&!u(`Search image`)&&l.push(/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.ActionSheetRow,{label:`Search image`,icon:/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.ActionSheetRow.Icon,{IconComponent:O}),onPress:function(){return P(s.searchUri,n)}},`media-utils-search`)),u(`Media options`)||l.push(/*#__PURE__*/ (0,t.jsx)(W,{store:r},`media-utils-options`)),valenced.react.React.cloneElement(a,{},valenced.react.React.cloneElement(c,{},...l))}))},{returnNamespace:!0,max:1/0}))}function K(e,n,r){e(valenced.modules.finders.getModules(valenced.modules.finders.filters.withName(`LongPressMessageActionSheet`),function(i){`default`in i&&typeof i.default==`function`&&e(valenced.patcher.instead(i,`default`,function(e,i){var a=Reflect.apply(i,this,e),o=e[0];if(typeof o!=`object`||!o||!(`message`in o))return a;var s=q(o);if(!s[0]||!valenced.react.React.isValidElement(a))return a;var c=a.props.children;if(!valenced.react.React.isValidElement(c))return a;var l=valenced.react.React.Children.toArray(c.props.children),u=l[0];if(!valenced.react.React.isValidElement(u))return a;var d=valenced.react.React.Children.toArray(u.props.children),f=s.filter(function(e){return e.kind===`image`}),p=f.map(function(e,r){return/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.ActionSheetRow,{label:f.length===1?`Search image`:`Search image ${r+1}`,icon:/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.ActionSheetRow.Icon,{IconComponent:O}),onPress:function(){return P(e.searchUri,n)}},`media-utils-search-${e.uri}`)});return l[0]=valenced.react.React.cloneElement(u,{},...d.slice(0,2),...p,/*#__PURE__*/ (0,t.jsx)(W,{store:r},`media-utils-options`),...d.slice(2)),valenced.react.React.cloneElement(a,{},valenced.react.React.cloneElement(c,{},...l))}))},{returnNamespace:!0,max:1/0}))}function q(e){if(`selectedMedia`in e&&e.selectedMedia!=null){var t=e.selectedMedia;if(typeof t!=`object`||!(`mediaType`in t)||t.mediaType!==`image`&&t.mediaType!==`video`||!(`mediaUrl`in t))return[];var n=k({uri:t.mediaUrl,contentType:t.mediaType===`video`?`video/mp4`:`image/png`});return n?[n]:[]}return!(`message`in e)||typeof e.message!=`object`||e.message===null||!(`attachments`in e.message)||!Array.isArray(e.message.attachments)?[]:e.message.attachments.flatMap(function(e){if(typeof e!=`object`||!e||!(`url`in e))return[];var t=`content_type`in e?e.content_type:void 0;if(typeof t!=`string`||!t.startsWith(`image/`)&&!t.startsWith(`video/`))return[];var n=k({uri:e.url,contentType:t});return n?[n]:[]})}function re(e){Array.isArray(e)&&(e=e[e.length-1]);var t=A(e);if(t&&typeof e==`object`&&e){var n=t.searchUri;if(/^https?:\/\/(?:cdn\.discordapp\.com|media\.discordapp\.net|images-ext-[^.]+\.discordapp\.net)\//i.test(n)){var r=n.indexOf(`#`),i=r<0?``:n.slice(r),a=r<0?n:n.slice(0,r),o=a.indexOf(`?`);if(o>=0){var s=a.slice(o+1).split(`&`).filter(function(e){return!/^(?:width|height|quality|format)=/i.test(e)}).join(`&`);n=a.slice(0,o)+(s?`?${s}`:``)+i}}return{...e,uri:n}}}var J=/* @__PURE__ */ new Map;function ie(e){return J.set(e,(J.get(e)??0)+1),function(){var t=J.get(e)??0;t<=1?J.delete(e):J.set(e,t-1)}}function Y(e){if(!valenced.react.React.isValidElement(e))return e;var t=e.props.source,n=typeof t==`object`&&!!t&&`uri`in t&&typeof t.uri==`string`&&J.has(t.uri),r=e.props.children;return r===void 0?n?valenced.react.React.cloneElement(e,{resizeMethod:`none`}):e:valenced.react.React.cloneElement(e,n?{resizeMethod:`none`}:{},valenced.react.React.Children.map(r,Y))}function X(e){e(function(){return J.clear()}),e(valenced.modules.finders.getModules(valenced.modules.finders.filters.withProps(`type`),function(t){typeof t.type==`function`&&t.type.name===`MediaModalImage`&&e(valenced.patcher.instead(t,`type`,function(e,t){return Y(Reflect.apply(t,this,e))}))},{max:1/0}))}function ae({children:e,zoomed:n,enabled:r=!0,reportError:i}){var[a,o]=valenced.react.React.useState(!1),[s,c]=valenced.react.React.useState(!1),[l,u]=valenced.react.React.useState(!1),[d,f]=valenced.react.React.useState(!1),p=valenced.react.React.isValidElement(e)?e:void 0,m=re(p?.props.source),h=m?.uri;valenced.react.React.useEffect(function(){r&&n&&o(!0)},[n,r]),valenced.react.React.useEffect(function(){if(r&&a&&h){var e=!1;return valenced.react.ReactNative.Image.prefetch(h).then(function(t){e||(t?c(!0):(u(!0),i(/* @__PURE__ */ Error(`MediaUtils: original image could not be loaded.`))))}).catch(function(t){e||(u(!0),i(t))}),function(){e=!0}}},[r,a,h,i]),valenced.react.React.useEffect(function(){if(r&&a&&!l&&h)return ie(h)},[r,a,l,h]);var g=p?.props.renderMedia;return!r||!p||!m||typeof g!=`function`?e:valenced.react.React.cloneElement(p,{renderMedia:function(...e){var n=Reflect.apply(g,this,e);return valenced.react.React.isValidElement(n)?/*#__PURE__*/ (0,t.jsxs)(valenced.react.ReactNative.View,{style:valenced.react.ReactNative.StyleSheet.absoluteFill,children:[(!d||l)&&/*#__PURE__*/ (0,t.jsx)(valenced.react.ReactNative.View,{style:valenced.react.ReactNative.StyleSheet.absoluteFill,children:n},`preview`),s&&!l&&/*#__PURE__*/ (0,t.jsx)(valenced.react.ReactNative.View,{pointerEvents:d?`auto`:`none`,style:[valenced.react.ReactNative.StyleSheet.absoluteFill,{opacity:+!!d}],children:valenced.react.React.cloneElement(n,{source:m,resizeMethod:`none`,onLoadStart:void 0,onLoad:function(){return f(!0)},onError:function(e){u(!0),i(e)}})},`original`)]}):n}})}var Z=function(){return{rotation:0,scale:1,x:0,y:0}};function Q(e,t,n,r,i={x:0,y:0}){var a=[...t].sort(function(e,t){return String(e.identifier).localeCompare(String(t.identifier))}),o=[...n].sort(function(e,t){return String(e.identifier).localeCompare(String(t.identifier))});if(a.length!==o.length||o.some(function(e,t){return e.identifier!==a[t]?.identifier}))return e;var s=a[0],c=o[0];if(!s||!c)return e;var l=a[1],u=o[1];if(!l||!u)return e.scale>1?{...e,x:e.x+c.pageX-s.pageX,y:e.y+c.pageY-s.pageY}:e;var d=l.pageX-s.pageX,f=l.pageY-s.pageY,p=u.pageX-c.pageX,m=u.pageY-c.pageY,h=Math.hypot(d,f);if(h<1)return e;var g=Math.atan2(m,p)-Math.atan2(f,d),_=e.rotation+Math.atan2(Math.sin(g),Math.cos(g)),v=Math.max(1,Math.min(r,e.scale*Math.hypot(p,m)/h)),y=v/e.scale,b=_-e.rotation,x=(s.pageX+l.pageX)/2-i.x,S=(s.pageY+l.pageY)/2-i.y,C=(c.pageX+u.pageX)/2-i.x,w=(c.pageY+u.pageY)/2-i.y,T=x-e.x,E=S-e.y;return{rotation:_,scale:v,x:v===1?0:C-y*(Math.cos(b)*T-Math.sin(b)*E),y:v===1?0:w-y*(Math.sin(b)*T+Math.cos(b)*E)}}function oe(e,t){e(valenced.modules.finders.getModules(valenced.modules.finders.filters.withName(`getMediaViewerStateForScreen`),function(n){`default`in n&&typeof n.default==`function`&&e(valenced.patcher.instead(n,`default`,function(e,n){var r=Reflect.apply(n,this,e);return!t()||typeof r!=`object`||!r?r:{...r,maximumZoomScale:100}}))},{returnNamespace:!0,max:1}))}var $=/* @__PURE__ */ new Set;function se(){for(var e of $)e()}function ce({viewer:e,reportError:n,store:r,kind:i}){var a=I(r.use()),o=valenced.react.React.useRef(a);o.current=a;var[s,c]=valenced.react.React.useState(!0),[l,u]=valenced.react.React.useState(!1),d=valenced.react.React.useRef(!0),f=valenced.react.React.useRef(null),p=valenced.react.React.useRef({x:0,y:0}),m=function(){return f.current?.measureInWindow(function(e,t,n,r){p.current={x:e+n/2,y:t+r/2}})},h=valenced.react.React.useRef(Z()),g=valenced.react.React.useRef([]),_=valenced.react.React.useRef(new valenced.react.ReactNative.Animated.Value(0)).current,v=valenced.react.React.useRef(new valenced.react.ReactNative.Animated.Value(1)).current,y=valenced.react.React.useRef(new valenced.react.ReactNative.Animated.Value(0)).current,b=valenced.react.React.useRef(new valenced.react.ReactNative.Animated.Value(0)).current,x=valenced.react.React.useRef(!1),S=valenced.react.React.useRef(e.props);S.current=e.props;var C=e.props.children,w=valenced.react.React.isValidElement(C),T=function(){var e=h.current;_.setValue(e.rotation),v.setValue(e.scale),y.setValue(e.x),b.setValue(e.y);var t=e.scale>1;t!==x.current&&(x.current=t,u(t),S.current.onZoomChanged?.({nativeEvent:{zoomScale:e.scale}}))},E=function(){g.current=[],h.current=Z(),T()};valenced.react.React.useImperativeHandle(e.props.ref,function(){return{zoomTo(e){if(o.current.zoomEnabled){var t=o.current.doubleTapZoom;g.current=[];var n=function(n,r,i,a){d.current&&(p.current={x:n+i/2,y:r+a/2},h.current={...h.current,scale:t,x:i>0?(i/2-Math.max(0,Math.min(i,e.x-n)))*(t-1):0,y:a>0?(a/2-Math.max(0,Math.min(a,e.y-r)))*(t-1):0},T())};f.current?f.current.measureInWindow(n):n(0,0,0,0)}},unzoom:E}});var D=valenced.react.React.useMemo(function(){var e=function(){return i===`video`?o.current.rotateVideos:o.current.rotateImages},t=function(){return e()||o.current.zoomEnabled},n=function(e){return d.current&&t()&&(e.nativeEvent.touches.length>=2||h.current.scale>1)},r=function(e){g.current=e.nativeEvent.touches.map(function(e){return{identifier:e.identifier,pageX:e.pageX,pageY:e.pageY}})};return valenced.react.ReactNative.PanResponder.create({onStartShouldSetPanResponderCapture:function(e){return d.current&&t()&&e.nativeEvent.touches.length>=2},onMoveShouldSetPanResponderCapture:function(e,t){return n(e)&&(e.nativeEvent.touches.length>=2||Math.hypot(t.dx,t.dy)>3)},onPanResponderGrant(e){m(),r(e)},onPanResponderMove(t){if(d.current){var n=t.nativeEvent.touches,i=Q(h.current,g.current,n,100,p.current);h.current={...i,rotation:e()?i.rotation:0,scale:o.current.zoomEnabled?i.scale:1,x:o.current.zoomEnabled?i.x:0,y:o.current.zoomEnabled?i.y:0},r(t),T()}},onPanResponderRelease(){g.current=[]},onPanResponderTerminate(){g.current=[]},onPanResponderTerminationRequest:function(){return!1},onShouldBlockNativeResponder:function(){return!0}})},[_,v,y,b]);return valenced.react.React.useEffect(function(){var e=function(){d.current=!1,h.current=Z(),T(),c(!1)};return $.add(e),function(){$.delete(e)}},[]),valenced.react.React.useEffect(function(){(i===`video`?a.rotateVideos:a.rotateImages)||(h.current.rotation=0),a.zoomEnabled||(h.current.scale=1,h.current.x=0,h.current.y=0),T()},[i,a.rotateImages,a.rotateVideos,a.zoomEnabled]),!s||!w?e:/*#__PURE__*/ (0,t.jsx)(valenced.react.ReactNative.View,{ref:f,onLayout:m,collapsable:!1,style:e.props.style,...D.panHandlers,children:valenced.react.React.cloneElement(C,{},/*#__PURE__*/ (0,t.jsx)(valenced.react.ReactNative.Animated.View,{collapsable:!1,style:[valenced.react.ReactNative.StyleSheet.absoluteFill,{transform:[{translateX:y},{translateY:b},{scale:v},{rotate:_.interpolate({inputRange:[-Math.PI,Math.PI],outputRange:[`-180deg`,`180deg`],extrapolate:`extend`})}]}],children:/*#__PURE__*/ (0,t.jsx)(ae,{zoomed:l&&a.fullResolution&&i===`image`,enabled:a.fullResolution&&i===`image`,reportError:n,children:C.props.children})}))})}return e.default={jsonStorage:{load:!0,default:F},SettingsComponent:ne,start({cleanup:e,plugin:n,jsonStorage:r}){var i=function(e){return n.reportError(e)};e(se),e(te),e(H),x(e,i),K(e,i,r),G(e,i,r),oe(e,function(){return I(r.cache).zoomEnabled}),X(e),D(e,function(){return I(r.cache).favoriteMedia}),e(valenced.modules.finders.getModules(valenced.modules.finders.filters.withProps(`useMediaShareActions`),function(t){e(valenced.patcher.instead(t,`useMediaShareActions`,function(e,t){var n=Reflect.apply(t,this,e),a=e[0];if(!Array.isArray(n)||typeof a!=`object`||!a||!(`source`in a))return n;var o=k(a.source);return o?[...n,...o.kind===`image`?[{label:`Search image`,IconComponent:O,action:function(){return P(o.searchUri,i)}}]:[],{label:`Media options`,IconComponent:U,action:function(){return V(r)}}]:n}))},{max:1})),e(valenced.modules.finders.getModules(valenced.modules.finders.filters.withProps(`MediaViewerItem`),function(n){var a=n.MediaViewerItem;typeof a!=`object`||!a||typeof a.type!=`function`?i(/* @__PURE__ */ Error(`MediaUtils: unsupported MediaViewerItem export.`)):e(valenced.patcher.instead(a,`type`,function(e,n){var a=Reflect.apply(n,this,e),o=e[0];if(typeof o!=`object`||!o||!(`source`in o))return a;var s=k(o.source);return!s||!valenced.react.React.isValidElement(a)?a:/*#__PURE__*/ (0,t.jsx)(ce,{viewer:a,kind:s.kind,store:r,reportError:i},s.uri)}))},{max:1}))}},e})({},valenced.react.ReactJSXRuntime);